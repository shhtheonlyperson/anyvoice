# Handoff — AnyVoice (personal voice cloning workspace)

> **Default locale: Traditional Chinese (zh-Hant). English is a toggle in the top bar.**

## Overview

AnyVoice is a personal voice-cloning workspace with three tools that share the same voice profiles:

- **建立聲音 / Build voice** — create a voice profile from recorded lines, a YouTube URL, or an uploaded clip; record / review / quality-gate 24 guided lines
- **生成 / Generate** — type any text and produce speech in a selected voice, with pace / warmth / breath controls
- **有聲書 / Audiobook** — upload EPUB/PDF, chapter-level reader with a background generation queue and a sticky player

The product is positioned as a **playground for personal & research use**. Voices are device-local; YouTube import is allowed only with an explicit playground-use acknowledgement.

## About the design files

The files in this bundle are **design references created in HTML/React + Babel** — runnable prototypes showing intended look and behavior, **not production code to copy directly**.

Your job is to recreate these designs in your target environment (React + your design system, Vue, SwiftUI, native, etc.) using your codebase's established patterns and libraries. If the project has no UI framework yet, pick the one that fits — these prototypes are framework-agnostic at the spec level.

The HTML prototypes use `<script type="text/babel">` JSX with no bundler, three React 18.3 + Babel CDN scripts, and one external stylesheet (`assets/claude.css`). Treat them as visual + interaction references.

## Fidelity

**High-fidelity.** Pixel-perfect mockups with final colors, typography, spacing, copy, and interactions. Recreate the UI pixel-perfectly using your codebase's libraries and patterns. Animations (typing waveforms, importing progress, line dots, sticky player) are part of the spec.

---

## Information architecture

```
┌─ Workspace shell ──────────────────────────────────────────────┐
│  Left rail (280px)         │   Top bar (60px)                  │
│   • Brand                  │     Tabs: Build / Generate / Book │
│   • Voices section         │     Lang toggle  Theme  Help      │
│     – per-voice fingerprint│                                   │
│     – status dot + label   │   Page area (scroll)              │
│     – source icon (YT/upload)                                  │
│   • Library section        │                                   │
│   • User footer            │                                   │
└─────────────────────────────────────────────────────────────────┘
```

The active voice in the rail drives the content shown in **Build voice**. In Generate and Audiobook the user picks a voice via a pill picker but the active rail voice is the default.

---

## Screens & views

### 1. Build voice — adaptive per voice state

Single page. The status of `activeVoice` selects between five sub-states:

| State        | Trigger                                      | Visual treatment |
|---|---|---|
| `empty`      | `voice.status === "empty"` and lineCount = 0 | Cream status card, single CTA "Start recording", empty-zone with three options |
| `importing`  | New voice from YT/upload (auto 4.2s)         | Dark status card with live waveform + 3-step progress dots |
| `recording`  | User clicked Start; local `mode === "recording"` | Dark recording stage + phoneme coverage sidecar |
| `reviewing`  | Voice has 1–23 lines done                    | Cream status card with progress donut + Continue CTA |
| `ready`      | Voice has all 24 lines done                  | Coral hero status card with "Start generating" CTA |

#### Header (always)

- Eyebrow `voice profile / 聲音檔案` — `--color-primary`, 11px, uppercase, tracking 1.5px
- H1 — Fraunces 52px / line-height 1.08 / tracking -1.4px. Title text varies by state (see i18n keys `build.title.*`).
- Lede — Inter 17px / 1.55 / muted color, max 560px width.
- Right side: Rename / Export / Delete ghost buttons. Hidden in `importing` state.

#### Status panel — `.build-status`

Flex-wrap container, 22px×26px padding, 16px radius.

- **Empty:** `--color-surface-card` bg. Title + sub on the left. CTA "Start recording" (coral primary, 48px tall).
- **Reviewing:** `--color-surface-card` bg. Inside left column: a 64px ink-stroke donut showing `lineCount / 24` next to title "Almost there — N lines to go" + sub. CTAs: "Pause for now" (secondary) + "Continue recording" (coral primary).
- **Ready:** `--color-primary` bg, white text. Inside: 64px white-stroke donut with check icon, title "Your voice is ready", sub. CTAs: "Listen back" (ghost on coral) + "Start generating" (cream secondary).

#### Recording stage — dark — when `mode === "recording"`

- Surface `--color-surface-dark`, 16px radius, 32px padding
- Eyebrow row with `Space to stop` kbd chip on the right
- Recording line — Fraunces 30px display text
- **Live waveform** — 80 bars, 88px tall, animated at ~250ms phrase pulse; bars represent simulated speech bursts (see "Waveform behavior" below)
- Controls: 64px round red record button (pulsing ring at 1.6s), elapsed timer (`mm:ss · target 6–20 s`), coach copy, Redo / Skip links

#### Phoneme coverage sidecar (recording state only)

- 320px width, dark card, 40 IPA phoneme cells (28×28px, 6px radius)
- Cells colored teal at three opacity tiers: missing → light → covered → strong. Active phonemes for the current line get a 2px primary ring.
- Legend at bottom (Strong / Light / Missing)

#### Lines list — 24 rows

Grid `36px | 1fr | auto`:

- Left: line number (JetBrains Mono 12px) + 8px **status dot** (`pass` success, `retry` warning, `fail` error, `todo` hairline, `recording` pulsing primary)
- Center: line text — Inter 15px / 1.5 / `--color-body-strong`
- Right: a 28-bar **micro waveform thumbnail** (color matches quality status), duration label, Play and Re-record icon buttons
- Hover: `--color-surface-soft`. Active row: same bg + bold text.

**Quality dots and the waveform thumbnails are derived from the same speech-quality function** (see `speechQuality()` in `src/components.jsx`) so they always agree.

### 2. Importing state — for YT / upload sources

Dark card. Eyebrow shows source ("YouTube" / "Upload" with respective icon). The source URL is shown as a serif display string. Live waveform under it. Below: a vertical 3-step progress list:

1. Capture audio clip
2. Transcribe speech
3. Build voice signature

Each step shows as:
- Pending: 0.4 opacity, gray dot
- Active: primary-colored dot with a pulsing inner circle, full opacity
- Done: green dot with white check, full opacity

Bottom row: `~12s` mono label on the left, "Cancel" link on the right. After 4.2s simulated time (replace with real progress in production), the voice becomes `ready`.

### 3. Create voice modal — `CreateVoiceModal`

Triggered by `+` in the rail's Voices section.

**Step 1 — chooser:** 3 equal-width cards (`.cv-option`):

- **Record lines** — Mic icon, "~12 minutes"
- **YouTube link** — YouTube icon, "~15 seconds"
- **Upload clip** — Upload icon, "~30 seconds"

Bottom: small centered disclaimer "Playground mode · voices stay on your device, nothing is uploaded".

**Step 2 — YouTube path:**

Amber warning banner: "Playground & personal research only. Don't use to impersonate or for commercial purposes."

Inputs:
- YouTube URL
- Auto-parsed preview card (visible once URL > 20 chars): YT icon thumb, channel, title, timestamp formatted as `mm:ss`, "Will capture ~12s from this timestamp"
- Voice name (auto-fills with channel name)
- Required checkbox: "I understand this is for playground use, not impersonation or commercial use."
- Back / "Build voice clone" (coral primary, disabled until URL + checkbox)

**Step 2 — Record path:** name input + language chips (繁體中文 / English / 日本語) + helpful guide card + "Start recording" CTA.

**Step 2 — Upload path:** name input + drag-and-drop area + "Continue" CTA.

### 4. Generate

#### Composer — cream wrapper around canvas-bg textarea

- Multi-line textarea, no border, 17px Inter, ~90px min height
- Toolbar row: voice picker pill (with VoiceMark thumb), 3 dials (Pace / Warmth / Breaths), char counter, primary "Generate" button

**Dials** are draggable horizontal mini-sliders:
- 60×4px track, 12px round handle with 2px coral border
- Format: Pace `slow / natural / brisk`, Warmth `cool / even / warm`, Breaths `0.00s` to `0.80s`

#### Result player — dark

- Eyebrow "Result" + voice fingerprint + name on the left, time on the right
- Full-width StaticWaveform (120 bars, 76px tall, speech-shaped) with played/cursor color states
- Controls: round white play button, speed group `1× / 1.25× / 1.5× / 2×` (active = coral), Volume / Share / WAV / Regenerate

#### Recent list

`subtab`s: Recent / Favorites / Shared. Rows:

```
[play] {text (2-line clamp), voice fingerprint + name · timestamp · duration} [mini-wave] [share / copy / more]
```

### 5. Audiobook — library

Wide page (1180px). 60/40 split:

- **Left:** "In progress" heading + 3-column book grid. Each card: a tall dark book cover with the Chinese title in Fraunces and a spike-mark accent, then `book-title` + `book-author`, then a coral progress bar + mono segment counter. Empty `+` upload card last.
- **Right:** "How it works" cream card with numbered 3-step (`01 / 02 / 03` mono badges).

### 6. Audiobook — reader

`240px chapter rail | 1fr reader body` two-column.

#### Chapter rail

- "Chapters" eyebrow + list of `chapter-item` rows. Active = cream-strong bg. Each row: 11px mono number, title (truncated), 8px status dot (`ready` success / `gen` pulsing warning / `queued` hairline).
- **Generation queue card** below — dark surface, lists chapters with live percentage / "queued" / "ready" labels.

#### Reader body

- Book hero: 110px tall cover beside `eyebrow author / h2 Fraunces 30px / subtitle muted / 3 status badges (ready / generating / queued)`.
- **Now playing card** — cream, 24px padding. Eyebrow "Now playing" + `Chapter X · Title` + `N segments · mm:ss total`. Inside it a dark inset showing a 140-bar speech waveform with played position. Below: Prev / Play (coral) / Next + speed group.
- **Transcript** — line-numbered (40px column) list of recent ±2 segments, current segment highlighted with cream-strong bg.

#### Sticky player bar

Dark, 12px radius, `auto | 1fr | auto` grid:

```
[play 36px] {Chapter title / book · voice · time}     [progress bar (flex)]
```

`position: sticky; bottom: 24px; z-index: 5`.

### 7. First-run modal

Translucent backdrop + 540px centered card. Eyebrow "Welcome to AnyVoice" + Fraunces 32px "Three minutes from here to a voice that's yours." 3 numbered steps (28px circle badges). Later / Start.

---

## Design tokens

All tokens live in `assets/claude.css`. Critical ones:

### Colors — light theme

| Token | Hex | Usage |
|---|---|---|
| `--color-canvas` | `#faf9f5` | Page floor |
| `--color-surface-soft` | `#f5f0e8` | Subtle hover, transcript bg |
| `--color-surface-card` | `#efe9de` | Standard cream card |
| `--color-surface-cream-strong` | `#e8e0d2` | Active list row |
| `--color-surface-dark` | `#181715` | Dark cards (recording, player, queue) |
| `--color-surface-dark-elevated` | `#252320` | Dark hover / secondary |
| `--color-primary` | `#cc785c` | Coral CTA, accent strokes, status |
| `--color-primary-active` | `#a9583e` | Coral press |
| `--color-accent-teal` | `#5db8a6` | Phoneme coverage |
| `--color-accent-amber` | `#e8a55a` | Building-state status |
| `--color-ink` | `#141413` | Strong text |
| `--color-body` | `#3d3d3a` | Body text |
| `--color-muted` | `#6c6a64` | Subtle text |
| `--color-hairline` | `#e6dfd8` | Dividers, inputs |
| `--color-success` | `#5db872` | Pass dots, ready chapters |
| `--color-warning` | `#d4a017` | Retry dots, generating chapters |
| `--color-error` | `#c64545` | Fail dots, destructive actions |

Dark-theme overrides on `.theme-dark` flip canvas/cards to warm near-black: `#1a1816`, `#221f1c`, `#2a2622`. Ink becomes `#f6f1e7`. Body becomes `#d8d2c5`. See `app.css`.

### Typography

| Role | Family | Size / LH / Tracking |
|---|---|---|
| Display H1 | Fraunces (substitute for Copernicus) wt 400 | 52 / 1.08 / -1.4px — drops to 42 / 1.08 / -1.1px under 900px |
| Display H2 | Fraunces wt 400 | 30 / 1.2 / -0.6px (book hero) |
| Display H5 | Fraunces wt 400 | 22 / 1.3 / -0.3px (now-playing chapter) |
| Body | Inter wt 400/500 | 16 / 1.55 (default), 17 / 1.55 (lede) |
| Title | Inter wt 500 | 14 / 1.4 |
| Eyebrow | Inter wt 500 | 11 / 1.4 / 1.5px tracking, uppercase, **coral on cream surfaces** |
| Caption | Inter wt 500 | 13 / 1.4 |
| Code / mono | JetBrains Mono | 14 / 1.6 |

Bold weight is reserved for product mockups; **display text is never bolder than 400** — the serif at regular weight is the editorial voice.

### Radii

`4 / 6 / 8 / 12 / 16 / 9999` — cards 14px, status panel 16px, inputs/buttons 8px, pills 9999px.

### Spacing

4px base unit. Used scale: `4 / 8 / 12 / 16 / 20 / 24 / 28 / 32 / 40 / 48 / 56 / 96`. Section padding `56px 48px 96px` (wide variant `48px 40px 96px`); cards `24-32px` padding.

### Shadows

Almost absent. Single elevated value `0 6px 24px rgba(20,20,19,0.10)` on the sticky player and modals. No hover-lift shadow stacks.

---

## Waveform behavior (custom)

All waveforms are generated by a deterministic speech-shaped function — they should **feel like recorded speech**, not random noise. The reference implementation is in `src/components.jsx`:

- `speechBars(seed, barCount, text, duration)` returns an array of `[0,1]` amplitude values shaped by:
  - **syllable count** inferred from text (CJK = 1 syllable/char, Latin words × 1.4) or duration (3.2 syll/s)
  - **gaussian syllable peaks** along the time axis with per-syllable amplitude variation
  - **punctuation pauses** that suppress amplitude in a narrow window (commas / 、 dampen by 45%; full stops / 。 / ! / ? dampen by 85%)
  - **phrase envelope** that ramps in over ~12% and out over ~18%
  - tiny consonant-noise jitter

- `speechQuality(seed, text, duration)` runs the same generator and grades it (mean, peak ratio, dynamic range, duration sanity). Returns `{status, score}` where status is `pass | retry | fail`. **The lines list dots and the line waveform thumbnails both consume this**, so quality and visual always agree.

- `LiveWaveform` (used in Recording stage and Importing card) layers three sine waves at different frequencies with a slow phrase envelope so it looks like live speech with occasional dips.

In production: replace `speechBars` with the actual recorded audio's per-frame RMS energy. Replace `speechQuality` with the model's real assessment (SNR, mic-distance, voicing %).

---

## VoiceMark (voice fingerprint)

Every voice has a unique radial SVG mark derived from a 16-bit hash. 36 spokes at angles `i/36 * 2π`. Each spoke's outer radius is `inner + (outer - inner) * amp[i]` where `amp[i]` comes from a seeded LCG. Color = status (`ready` coral / `building` amber / `empty` muted).

This is mostly cosmetic identity, but it should **be deterministic for a given voice** so users learn to recognize their voices by glance.

---

## Interactions & behavior

- **Toggle theme:** `--color-primary` and `--color-primary-active` are recomputed on accent change. Adds `.theme-dark` to `<html>`.
- **Language toggle:** updates `document.documentElement.lang` to `zh-Hant` or `en`. All visible strings flow through `useT()`; see `src/i18n.jsx` for the complete keyset.
- **Create voice:** rail `+` opens a modal. Choosing Record creates an empty voice and routes to Build; YT/Upload creates an `importing` voice that auto-promotes to `ready` after 4.2s (replace with real backend progress).
- **Recording loop:** `Start recording` flips local `mode` to `"recording"`, picks the first todo line as the current line; pressing the record button (`onStop`) marks the line as pass and advances to next todo; auto-exits to `reviewing` when all 24 are done.
- **Generate:** clicking Generate disables for 900ms (simulated), then pushes the previous result into the recent list and shows the new one in the dark player. Player has play/pause, speed, share/download, regenerate.
- **Audiobook reader:** chapters with status `queued` are unclickable. Sticky player follows the page.
- **Tweaks panel:** floats bottom-right. Mode (Light/Dark), accent swatches (6 colors), rail collapse, jump-to-state shortcuts, demo modal triggers.

---

## State management

```
voices: Voice[]                  // sample defaults in src/data.jsx
activeVoiceId: string
activeTab: "build" | "generate" | "audiobook"
lang: "zh" | "en"               // default "zh"
theme: "light" | "dark"          // default "light"
railCollapsed: boolean
speakingVoiceId: string | null   // for "currently playing" indicator
showCreateVoice / showFirstRun: boolean

type Voice = {
  id: string;
  name: string;
  status: "empty" | "importing" | "building" | "ready";
  source?: "record" | "yt" | "upload";
  sourceUrl?: string;
  hash: number;
  lineCount: number;
  totalLines: 24;
  lang: "zh-TW" | "en-US" | "ja-JP" | ...;
};
```

`Voice.subtitle` is computed on the fly by `voiceSubtitle(v, lang)` in `src/i18n.jsx` — don't store it.

---

## Assets

- `assets/claude.css` — all design tokens (foreground design system stylesheet)
- `assets/spike-mark.svg` — Anthropic-style spike glyph (used inline before "AnyVoice" wordmark and as book-cover marker). Replace with your real logo asset.

No raster art is used. All icons are line SVGs hand-drawn in `src/icons.jsx`, modeled on Lucide proportions (1.75px stroke, 24px viewBox).

---

## Files included in this handoff

```
design_handoff_anyvoice/
├── README.md                       (this file)
├── AnyVoice.html                   main prototype (start here)
├── States Canvas.html              all 12 key states side-by-side
├── app.css                         app-specific styles beyond design tokens
├── assets/
│   ├── claude.css                  design tokens + base type
│   └── spike-mark.svg              brand glyph
├── tweaks-panel.jsx                self-contained Tweaks shell
├── design-canvas.jsx               canvas for States Canvas.html
└── src/
    ├── icons.jsx                   line-icon library
    ├── i18n.jsx                    full zh + en translations + helpers
    ├── data.jsx                    sample voices / lines / books / phonemes
    ├── components.jsx              VoiceMark, waveforms, donut, ripples
    ├── shell.jsx                   workspace shell (rail + topbar)
    ├── create-voice.jsx            create-voice modal flow
    ├── build.jsx                   Build voice page + all sub-states
    ├── generate.jsx                Generate composer + player + recent
    ├── audiobook.jsx               library + reader + queue
    ├── canvas.jsx                  states canvas composition
    └── main.jsx                    app entry / routing / theming
```

## Quick start

To run the prototype as-is:

```bash
# any static server
npx http-server design_handoff_anyvoice -o /AnyVoice.html
```

Then open `http://localhost:8080/AnyVoice.html`.

## Implementation notes for your codebase

- **Don't ship the in-browser Babel transformer.** It's there only because the prototype runs as a single static folder. In production, transpile the JSX through your build pipeline.
- **Don't ship `claude.css` verbatim.** Lift the token names you need into your existing design-token system. If you already have a token system, only port the *missing* values (the warm canvas palette + the coral pair are the differentiators).
- **The waveforms are math, not audio.** For production, plumb real RMS energy from your audio pipeline into the same SVG/CSS bar component. Keep the speech-shaped fallback for placeholder/loading states.
- **Quality dots = single source of truth.** Keep dot color, waveform color, and quality model output coupled. Don't let UI display "pass" while the backend has flagged the line.
- **i18n is positional with `{var}` interpolation.** Pluralization is naïve (no plural-forms library). Use ICU MessageFormat or your existing i18n lib for production.
- **VoiceMark deterministically maps hash→shape.** Store and persist the hash, not the rendered SVG, so the mark survives serialization.

---

If anything in the spec is ambiguous, the source of truth is the rendered prototype — open `AnyVoice.html` and the State Canvas in a browser.
