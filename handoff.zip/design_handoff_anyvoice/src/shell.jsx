/* Workspace shell: left rail (voices + nav) + topbar (tabs + lang/theme) */

const { useState } = React;

function WorkspaceShell({
  voices, activeVoiceId, onSelectVoice, onCreateVoice,
  activeTab, onChangeTab,
  lang, onToggleLang,
  theme, onToggleTheme,
  speakingVoiceId,
  railCollapsed, onToggleRail,
  children,
}) {
  const t = useT();
  const Spike = window.SpikeIcon;
  return (
    <div className={`workspace ${railCollapsed ? "rail-collapsed" : ""}`}>
      {/* ============== Left rail ============== */}
      <aside className="rail">
        <div className="rail-head">
          {!railCollapsed && (
            <div className="rail-brand">
              <Spike size={18}/>
              <span>{t("brand.name")}</span>
            </div>
          )}
          {railCollapsed && <Spike size={20} style={{color: "var(--color-primary)", margin: "0 auto"}}/>}
          {!railCollapsed && (
            <button className="rail-collapse" onClick={onToggleRail} title={t("topbar.collapseRail")}>
              <IcPanelLeft size={16}/>
            </button>
          )}
        </div>

        {!railCollapsed && (
          <>
            <div className="rail-section">
              <span className="rail-section-label">{t("rail.voices")}</span>
              <button className="rail-section-action" onClick={onCreateVoice} title={t("rail.newVoice")}>
                <IcPlus size={14}/>
              </button>
            </div>
            <div className="voice-list">
              {voices.map(v => (
                <div
                  key={v.id}
                  className={`voice-item ${v.id === activeVoiceId ? "active" : ""} ${v.id === speakingVoiceId ? "speaking" : ""}`}
                  onClick={() => onSelectVoice(v.id)}
                >
                  <div className="vm-wrap">
                    <VoiceMark hash={v.hash} status={v.status} size={32} dim={v.status === "empty"}/>
                    <span className={`vm-status ${v.status === "importing" ? "building" : v.status}`}/>
                  </div>
                  <div className="voice-meta">
                    <div className="voice-name">{v.name}</div>
                    <div className="voice-sub">{voiceSubtitle(v, lang)}</div>
                  </div>
                  {v.source === "yt" && <IcYoutube size={12} style={{color:"var(--color-muted-soft)", flexShrink:0}}/>}
                  <IcWave size={14} className="vm-speaking"/>
                </div>
              ))}
            </div>

            <div className="rail-section" style={{marginTop: 16}}>
              <span className="rail-section-label">{t("rail.library")}</span>
            </div>
            <div className="rail-nav">
              <button className="rail-link"><IcLibrary size={16}/> {t("rail.generations")}</button>
              <button className="rail-link"><IcHeadphones size={16}/> {t("rail.audiobooks")}</button>
              <button className="rail-link"><IcLayers size={16}/> {t("rail.datasets")}</button>
            </div>

            <div className="rail-foot">
              <div className="avatar">G</div>
              <div className="who">
                <div className="name">{t("rail.user")}</div>
                <div className="plan">{t("rail.plan")}</div>
              </div>
              <button className="icon-btn" title="Settings"><IcSettings size={16}/></button>
            </div>
          </>
        )}

        {railCollapsed && (
          <>
            <div className="voice-list" style={{padding: "6px 14px"}}>
              {voices.map(v => (
                <button
                  key={v.id}
                  className={`voice-item ${v.id === activeVoiceId ? "active" : ""}`}
                  onClick={() => onSelectVoice(v.id)}
                  title={v.name}
                  style={{padding: 8, justifyContent: "center"}}
                >
                  <div className="vm-wrap">
                    <VoiceMark hash={v.hash} status={v.status} size={32} dim={v.status === "empty"}/>
                    <span className={`vm-status ${v.status === "importing" ? "building" : v.status}`}/>
                  </div>
                </button>
              ))}
              <button className="voice-item" onClick={onCreateVoice} title={t("rail.newVoice")} style={{padding: 8, justifyContent: "center"}}>
                <div className="vm-wrap" style={{width: 32, height: 32, borderRadius: "50%", background: "var(--color-surface-card)", color:"var(--color-muted)", display:"flex", alignItems:"center", justifyContent:"center"}}>
                  <IcPlus size={16}/>
                </div>
              </button>
            </div>
            <button className="rail-collapse" onClick={onToggleRail} style={{margin: "auto auto 14px"}} title={t("topbar.expandRail")}>
              <IcChevron size={16}/>
            </button>
          </>
        )}
      </aside>

      {/* ============== Main pane ============== */}
      <main className="workspace-main">
        <header className="topbar">
          <div className="row gap-12">
            {railCollapsed && (
              <button className="icon-btn" onClick={onToggleRail} title={t("topbar.expandRail")}>
                <IcPanelLeft size={16}/>
              </button>
            )}
            <div className="tabs">
              <button className={`tab ${activeTab === "build" ? "active" : ""}`} onClick={() => onChangeTab("build")}>
                <IcMic size={14}/> {t("tab.build")}
              </button>
              <button className={`tab ${activeTab === "generate" ? "active" : ""}`} onClick={() => onChangeTab("generate")}>
                <IcSparkles size={14}/> {t("tab.generate")}
              </button>
              <button className={`tab ${activeTab === "audiobook" ? "active" : ""}`} onClick={() => onChangeTab("audiobook")}>
                <IcBook size={14}/> {t("tab.audiobook")}
              </button>
            </div>
          </div>
          <div className="topbar-right">
            <button className="lang-toggle" onClick={onToggleLang} title={t("topbar.changeLanguage")}>
              <IcGlobe size={14}/>
              <span>{lang === "zh" ? "中" : "EN"}</span>
            </button>
            <button className="icon-btn" onClick={onToggleTheme} title={t("topbar.toggleTheme")}>
              {theme === "dark" ? <IcSun size={16}/> : <IcMoon size={16}/>}
            </button>
            <button className="icon-btn" title={t("topbar.help")}><IcInfo size={16}/></button>
          </div>
        </header>
        <div className="page">
          {children}
        </div>
      </main>
    </div>
  );
}

Object.assign(window, { WorkspaceShell });
