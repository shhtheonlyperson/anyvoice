/* States Canvas — showcases each major flow state side-by-side */

const { useState, useEffect } = React;

/* Mini workspace shell as a static frame inside each artboard */
function Frame({ children, theme = "light" }) {
  return (
    <div className={`frame ${theme === "dark" ? "theme-dark" : ""}`}
      style={{
        width: "100%", height: "100%",
        background: "var(--color-canvas)",
        overflow: "hidden", display: "flex",
      }}>
      {children}
    </div>
  );
}

function MiniRail({ activeId = "v_main", theme }) {
  return (
    <aside className="rail" style={{width: 232, flexShrink: 0}}>
      <div className="rail-head">
        <div className="rail-brand"><SpikeIcon size={16} style={{color:"var(--color-primary)"}}/><span style={{fontSize: 17}}>AnyVoice</span></div>
      </div>
      <div className="rail-section"><span className="rail-section-label">Voices</span></div>
      <div className="voice-list">
        {sampleVoices.map(v => (
          <div key={v.id} className={`voice-item ${v.id === activeId ? "active" : ""}`}>
            <div className="vm-wrap"><VoiceMark hash={v.hash} status={v.status} size={28} dim={v.status === "empty"}/><span className={`vm-status ${v.status}`}/></div>
            <div className="voice-meta">
              <div className="voice-name" style={{fontSize: 13}}>{v.name}</div>
              <div className="voice-sub" style={{fontSize: 10.5}}>{v.subtitle}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="rail-section" style={{marginTop: 16}}><span className="rail-section-label">Library</span></div>
      <div className="rail-nav">
        <button className="rail-link" style={{fontSize: 12}}><IcLibrary size={14}/>Generations</button>
        <button className="rail-link" style={{fontSize: 12}}><IcHeadphones size={14}/>Audiobooks</button>
      </div>
      <div className="rail-foot">
        <div className="avatar" style={{width: 28, height: 28, fontSize:12}}>G</div>
        <div className="who">
          <div className="name" style={{fontSize:12}}>Glory</div>
          <div className="plan" style={{fontSize:10}}>Personal use</div>
        </div>
      </div>
    </aside>
  );
}

function MiniTopbar({ activeTab = "build" }) {
  return (
    <header className="topbar" style={{height: 52, padding: "0 20px"}}>
      <div className="tabs">
        <button className={`tab ${activeTab === "build" ? "active" : ""}`}><IcMic size={13}/>Build voice</button>
        <button className={`tab ${activeTab === "generate" ? "active" : ""}`}><IcSparkles size={13}/>Generate</button>
        <button className={`tab ${activeTab === "audiobook" ? "active" : ""}`}><IcBook size={13}/>Audiobook</button>
      </div>
      <div className="topbar-right">
        <button className="lang-toggle"><IcGlobe size={14}/>EN</button>
        <button className="icon-btn"><IcMoon size={16}/></button>
      </div>
    </header>
  );
}

function FrameShell({ activeId, activeTab, theme, children }) {
  return (
    <Frame theme={theme}>
      <MiniRail activeId={activeId} theme={theme}/>
      <main className="workspace-main">
        <MiniTopbar activeTab={activeTab}/>
        <div className="page">{children}</div>
      </main>
    </Frame>
  );
}

/* ===== Build · Empty ===== */
function StateBuildEmpty() {
  return (
    <FrameShell activeId="v_late" activeTab="build">
      <div className="page-inner" style={{padding: "36px 36px"}}>
        <div className="eyebrow">Voice profile</div>
        <h1 className="page-title">Build your digital voice</h1>
        <p className="page-lede">Record 24 guided lines in a quiet room, at your natural pace. Each takes 6–20 seconds. Your voice never leaves this device.</p>
        <div className="build-status mt-32">
          <div className="build-status-content">
            <div className="build-status-title">Let's give "Late-night" a voice</div>
            <div className="build-status-sub">Record 24 short lines. About 12 minutes start to finish.</div>
          </div>
          <div className="build-cta">
            <button className="btn btn--secondary"><IcYoutube size={14}/>Import</button>
            <button className="btn btn--primary"><IcMic size={14}/>Start recording</button>
          </div>
        </div>
        <div className="empty-zone mt-48">
          <div className="ill"><IcMic size={24}/></div>
          <h3>Three ways to get a voice</h3>
          <p>Record 24 lines, import from YouTube, or upload a clean clip.</p>
        </div>
      </div>
    </FrameShell>
  );
}

/* ===== Build · Recording ===== */
function StateBuildRecording() {
  const coverage = buildCoverage(0x2b5e, 12);
  const line = sampleLines[12];
  return (
    <FrameShell activeId="v_pod" activeTab="build">
      <div className="page-inner" style={{padding: "32px 36px", maxWidth: 1100}}>
        <div className="eyebrow">Voice profile</div>
        <h1 className="page-title" style={{fontSize: 42, letterSpacing: "-1px"}}>Recording in progress</h1>
        <p className="page-lede">Read the line below at your normal pace. We're listening for clarity, not perfection.</p>

        <div className="rec-stage mt-24">
          <div className="row between" style={{marginBottom: 12}}>
            <div className="eyebrow" style={{color:"var(--color-primary)", margin: 0}}>Recording · Line 13 of 24</div>
            <div className="row gap-8" style={{color:"var(--color-on-dark-soft)", fontSize: 13}}>
              <span className="kbd" style={{background:"rgba(255,255,255,0.06)", borderColor:"rgba(255,255,255,0.1)", color:"var(--color-on-dark-soft)"}}>Space</span>
              <span>to stop</span>
            </div>
          </div>
          <div className="rec-line">{line.text}</div>
          <LiveWaveform active={true} bars={70} height={80}/>
          <div className="rec-controls">
            <div className="row gap-12">
              <button className="rec-btn recording"><IcSquare size={20}/></button>
              <div>
                <div className="rec-timer">0:08 <span style={{opacity:0.5}}>· target 6–20s</span></div>
                <div style={{fontSize: 11, color:"var(--color-on-dark-soft)", marginTop: 4}}>Pause between sentences.</div>
              </div>
            </div>
          </div>
        </div>

        <div style={{display:"grid", gridTemplateColumns: "1fr 280px", gap: 24, marginTop: 24}}>
          <div className="lines-list" style={{marginTop: 0}}>
            {sampleLines.slice(10, 15).map((L, i) => (
              <div key={L.id} className={`line-row ${i === 2 ? "active" : ""}`}>
                <div className="row gap-12"><span className="line-num">{String(L.id).padStart(2,"0")}</span><span className={`line-status-dot ${i < 2 ? "pass" : i === 2 ? "recording" : "todo"}`}/></div>
                <div className="line-text" style={{fontSize: 14}}>{L.text}</div>
                <div className="line-actions"><span className="line-meta">{L.duration.toFixed(1)}s</span></div>
              </div>
            ))}
          </div>
          <div className="card-dark" style={{padding: 18}}>
            <div className="row between" style={{marginBottom: 10}}>
              <span className="player-eyebrow">Phonemes</span>
              <span className="player-time">28 / 40</span>
            </div>
            <div className="phoneme-row">
              {phonemes.slice(0, 28).map(p => {
                const c = coverage[p] || 0;
                const cls = c >= 6 ? "covered-3" : c >= 3 ? "covered-2" : c >= 1 ? "covered" : "";
                return <span key={p} className={`phoneme-cell ${cls}`} style={{width:22, height:22, fontSize:10}}>{p}</span>;
              })}
            </div>
          </div>
        </div>
      </div>
    </FrameShell>
  );
}

/* ===== Build · Reviewing ===== */
function StateBuildReviewing() {
  return (
    <FrameShell activeId="v_pod" activeTab="build">
      <div className="page-inner" style={{padding: "36px 36px"}}>
        <div className="eyebrow">Voice profile</div>
        <h1 className="page-title">Almost a voice</h1>
        <p className="page-lede">A few lines could use a re-record. We've flagged them so you know what's worth a second take.</p>
        <div className="build-status mt-32">
          <div className="build-status-content">
            <div className="coverage-meta">
              <Donut value={0.5} size={64} stroke={6} color="var(--color-ink)" track="var(--color-hairline)" label="50%"/>
              <div>
                <div className="build-status-title">Almost there — 12 lines to go</div>
                <div className="build-status-sub">Quality looks good. Keep going at your own pace.</div>
              </div>
            </div>
          </div>
          <div className="build-cta">
            <button className="btn btn--secondary">Pause</button>
            <button className="btn btn--primary"><IcMic size={14}/>Continue</button>
          </div>
        </div>

        <div className="lines-list mt-32">
          {sampleLines.slice(0, 6).map(L => (
            <div key={L.id} className="line-row">
              <div className="row gap-12"><span className="line-num">{String(L.id).padStart(2,"0")}</span><span className={`line-status-dot ${L.status}`}/></div>
              <div className="line-text">{L.text}</div>
              <div className="line-actions"><span className="line-meta">{L.duration.toFixed(1)}s</span></div>
            </div>
          ))}
        </div>
      </div>
    </FrameShell>
  );
}

/* ===== Build · Ready ===== */
function StateBuildReady() {
  return (
    <FrameShell activeId="v_main" activeTab="build">
      <div className="page-inner" style={{padding: "36px 36px"}}>
        <div className="eyebrow">Voice profile</div>
        <h1 className="page-title">Your voice is ready</h1>
        <p className="page-lede">All 24 lines passed our quality checks. You can use this voice in Generate and Audiobook now.</p>
        <div className="build-status ready mt-32">
          <div className="build-status-content">
            <div className="coverage-meta">
              <Donut value={1} size={64} stroke={6} color="#fff" track="rgba(255,255,255,0.25)" label={<IcCheck size={20} style={{color:"#fff"}}/>}/>
              <div>
                <div className="build-status-title">Your voice is ready</div>
                <div className="build-status-sub">All 24 lines passed quality checks.</div>
              </div>
            </div>
          </div>
          <div className="build-cta">
            <button className="btn btn--ghost" style={{color:"#fff"}}>Listen back</button>
            <button className="btn btn--secondary">Start generating <IcChevron size={14}/></button>
          </div>
        </div>
        <div className="lines-list mt-32">
          {sampleLines.slice(0, 5).map(L => (
            <div key={L.id} className="line-row">
              <div className="row gap-12"><span className="line-num">{String(L.id).padStart(2,"0")}</span><span className="line-status-dot pass"/></div>
              <div className="line-text">{L.text}</div>
              <div className="line-actions"><span className="line-meta">{L.duration.toFixed(1)}s</span></div>
            </div>
          ))}
        </div>
      </div>
    </FrameShell>
  );
}

/* ===== Build · YouTube import ===== */
function StateImportYouTube() {
  return (
    <FrameShell activeId="v_late" activeTab="build">
      <div className="page-inner" style={{padding: "40px 36px"}}>
        <div className="eyebrow">Import a voice</div>
        <h1 className="page-title">Borrow a voice you have rights to</h1>
        <p className="page-lede">Paste a YouTube URL with a timestamp. We pull 12 seconds from that point.</p>
        <div className="card-cream mt-32">
          <div className="row between" style={{alignItems:"start", marginBottom: 16}}>
            <div>
              <div className="row gap-8" style={{marginBottom: 6}}>
                <IcYoutube size={20} style={{color:"var(--color-primary)"}}/>
                <h5 style={{margin:0, fontSize: 17, fontWeight: 500}}>Import a voice from YouTube</h5>
              </div>
              <p style={{margin:0, fontSize: 13, color:"var(--color-muted)", maxWidth: 480}}>
                URL with <span className="kbd">&amp;t=300</span> starts at 5:00. Transcript is auto-detected.
              </p>
            </div>
            <span className="badge">Personal use only</span>
          </div>
          <label className="input-label">YouTube URL</label>
          <input className="input" defaultValue="https://www.youtube.com/watch?v=uvxToFIeG5o&t=300"/>
          <div className="row gap-12 mt-16">
            <label className="row gap-8" style={{fontSize:13, color:"var(--color-body)"}}>
              <input type="checkbox" defaultChecked/> I have the right to use this voice.
            </label>
            <div style={{flex:1}}/>
            <button className="btn btn--primary"><IcDownload size={14}/>Import</button>
          </div>
        </div>
      </div>
    </FrameShell>
  );
}

/* ===== Generate · Composer + result ===== */
function StateGenerate() {
  return (
    <FrameShell activeId="v_main" activeTab="generate">
      <div className="page-inner" style={{padding: "32px 36px"}}>
        <div className="eyebrow">Digital voice clone</div>
        <h1 className="page-title" style={{fontSize: 42, letterSpacing:"-1px"}}>Make your voice say anything</h1>
        <p className="page-lede">Type any text. Adjust pace, warmth, and breathing — the changes are subtle but they matter.</p>

        <div className="compose-shell mt-24">
          <div className="compose-input-wrap">
            <div style={{fontFamily:"var(--font-body)", fontSize: 16, color:"var(--color-ink)", lineHeight: 1.55}}>
              台積電是世界頂尖的半導體公司，多年來在世界競爭中持續領先，源自於我們有世界上最優秀的夥伴。
            </div>
          </div>
          <div className="compose-toolbar">
            <div className="compose-tools-left">
              <span className="voice-pill"><VoiceMark hash={0x4a7d} size={20}/><span>我的聲音</span><IcChevronDown size={12}/></span>
              <span className="dial"><span className="dial-label">Pace</span><div className="dial-track" style={{width:50}}><div className="dial-fill" style={{width:"50%"}}/><div className="dial-handle" style={{left:"50%"}}/></div><span className="dial-val">nat</span></span>
              <span className="dial"><span className="dial-label">Warmth</span><div className="dial-track" style={{width:50}}><div className="dial-fill" style={{width:"60%"}}/><div className="dial-handle" style={{left:"60%"}}/></div><span className="dial-val">warm</span></span>
            </div>
            <button className="btn btn--primary"><IcSparkles size={14}/>Generate</button>
          </div>
        </div>

        <div className="player mt-24">
          <div className="player-head">
            <div className="row gap-12">
              <span className="player-eyebrow">Result</span>
              <div className="row gap-8" style={{color:"var(--color-on-dark)"}}><VoiceMark hash={0x4a7d} size={16}/><span style={{fontSize: 13}}>我的聲音</span></div>
            </div>
            <span className="player-time">0:00 / 0:17</span>
          </div>
          <StaticWaveform seed={0x7a21} bars={100} height={70} played={0.32}/>
          <div className="player-controls">
            <div className="player-controls-left">
              <button className="play-btn"><IcPlay size={16}/></button>
              <div className="speed-group">
                {[1, 1.25, 1.5, 2].map(s => <button key={s} className={`speed-btn ${s === 1.25 ? "active" : ""}`}>{s}×</button>)}
              </div>
            </div>
            <div className="player-controls-right">
              <button className="dark-link-btn"><IcShare size={14}/>Share</button>
              <button className="dark-link-btn"><IcDownload size={14}/>WAV</button>
            </div>
          </div>
        </div>
      </div>
    </FrameShell>
  );
}

/* ===== Audiobook library ===== */
function StateAudiobookLibrary() {
  return (
    <FrameShell activeId="v_main" activeTab="audiobook">
      <div className="page-inner wide" style={{padding: "36px 36px"}}>
        <div className="eyebrow">Audiobook</div>
        <h1 className="page-title md">Turn a book into an audiobook</h1>
        <p className="page-lede">Upload an EPUB or PDF. Listen as soon as the first chapter is ready.</p>
        <div className="book-grid mt-32" style={{gridTemplateColumns:"repeat(3, 1fr)"}}>
          {sampleBooks.map(b => (
            <div key={b.id} className="book-card">
              <div className="book-cover" style={{background: b.cover.bg}}>
                <SpikeIcon className="book-cover-mark" style={{color: b.cover.accent}}/>
                <div className="title-zh">{b.title}</div>
              </div>
              <div>
                <div className="book-title">{b.title}</div>
                <div className="book-author">{b.author}</div>
              </div>
              <Progress value={b.progressSegments / b.totalSegments}/>
              <div className="progress-meta">
                <span>{b.progressSegments} / {b.totalSegments}</span>
                <span>{Math.round(b.progressSegments / b.totalSegments * 100)}%</span>
              </div>
            </div>
          ))}
          <div className="book-upload-card">
            <IcUpload size={18}/>
            <div style={{fontSize: 13, fontWeight: 500, color:"var(--color-ink)"}}>Upload EPUB or PDF</div>
            <div style={{fontSize: 11, color:"var(--color-muted)"}}>Up to 800 pages</div>
          </div>
        </div>
      </div>
    </FrameShell>
  );
}

/* ===== Audiobook reader ===== */
function StateAudiobookReader() {
  const book = sampleBooks[0];
  return (
    <FrameShell activeId="v_main" activeTab="audiobook">
      <div className="page-inner wide" style={{padding: "28px 32px"}}>
        <div className="row gap-8" style={{marginBottom: 14}}>
          <button className="btn btn--ghost btn--sm"><IcChevronLeft size={14}/>All audiobooks</button>
        </div>
        <div style={{display:"grid", gridTemplateColumns:"220px 1fr", gap: 28}}>
          <aside>
            <div style={{fontSize:11, fontWeight:500, letterSpacing:1.2, textTransform:"uppercase", color:"var(--color-muted)", marginBottom: 10}}>Chapters</div>
            {book.chapters.slice(0, 7).map(c => (
              <div key={c.id} className={`chapter-item ${c.id === 2 ? "active" : ""}`}>
                <span className="ch-num">{String(c.id).padStart(2,"0")}</span>
                <span className="ch-title">{c.title}</span>
                <span className={`ch-status ${c.status}`}/>
              </div>
            ))}
            <div className="queue-card" style={{marginTop: 14}}>
              <div className="queue-head" style={{marginBottom: 10}}>
                <span className="player-eyebrow">Queue</span>
                <span style={{fontFamily:"var(--font-mono)", fontSize: 11, color:"var(--color-on-dark-soft)"}}>4 of 7</span>
              </div>
              {book.chapters.slice(3, 7).map(c => (
                <div key={c.id} className="queue-row">
                  <span className="q-num">{String(c.id).padStart(2,"0")}</span>
                  <span className="q-title">{c.title}</span>
                  <span className="q-status">
                    {c.status === "gen" && <><span className="gen-dot"/>35%</>}
                    {c.status === "queued" && <><span className="queued-dot"/>queued</>}
                  </span>
                </div>
              ))}
            </div>
          </aside>
          <div>
            <div style={{display:"grid", gridTemplateColumns: "110px 1fr", gap: 22, marginBottom: 24}}>
              <div className="book-cover" style={{background: book.cover.bg}}>
                <SpikeIcon className="book-cover-mark" style={{color: book.cover.accent}}/>
                <div className="title-zh" style={{fontSize: 18}}>{book.title}</div>
              </div>
              <div>
                <div className="eyebrow">{book.author}</div>
                <h2 style={{fontFamily:"var(--font-display)", fontWeight:400, fontSize: 28, letterSpacing:"-0.5px", margin:"4px 0 6px"}}>{book.title}</h2>
                <p style={{fontSize: 13, color:"var(--color-muted)", margin:"0 0 12px"}}>{book.subtitle}</p>
                <div className="row gap-8">
                  <span className="badge"><IcCheck size={12} style={{marginRight: 4}}/>3 ready</span>
                  <span className="badge" style={{background:"var(--color-canvas)", border:"1px solid var(--color-hairline)"}}>1 generating</span>
                  <span className="badge" style={{background:"var(--color-canvas)", border:"1px solid var(--color-hairline)"}}>3 queued</span>
                </div>
              </div>
            </div>
            <div className="card-cream" style={{padding: 20}}>
              <div className="eyebrow" style={{margin:0, color:"var(--color-primary)"}}>Now playing</div>
              <h5 style={{fontFamily:"var(--font-display)", fontWeight: 400, fontSize: 22, margin: "6px 0 12px", letterSpacing:"-0.3px"}}>Chapter 2 · A Mutational Beginning</h5>
              <div style={{background:"var(--color-surface-dark)", borderRadius: 10, padding: 16}}>
                <StaticWaveform seed={142} bars={100} height={50} played={0.32}/>
              </div>
              <div className="row between mt-16">
                <div className="row gap-8">
                  <button className="btn btn--ghost btn--sm"><IcSkipBack size={12}/>Prev</button>
                  <button className="btn btn--primary btn--sm"><IcPlay size={12}/>Play</button>
                  <button className="btn btn--ghost btn--sm">Next<IcSkipFwd size={12}/></button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </FrameShell>
  );
}

/* ===== System · First-run modal ===== */
function StateFirstRun() {
  return (
    <div style={{
      position:"relative", width:"100%", height:"100%",
      background:"rgba(20,20,19,0.55)",
      display:"flex", alignItems:"center", justifyContent:"center",
      padding: 24,
    }}>
      {/* Background shell */}
      <div style={{
        position:"absolute", inset: 0, opacity: 0.4,
        background:"var(--color-canvas)",
      }}/>
      <div className="first-run-card" style={{position: "relative", maxWidth: 520}}>
        <div className="row gap-12" style={{marginBottom: 6}}>
          <SpikeIcon size={18} style={{color:"var(--color-primary)"}}/>
          <span className="eyebrow" style={{margin:0}}>Welcome to AnyVoice</span>
        </div>
        <h2>Three minutes from here to a voice that's yours.</h2>
        <div className="mt-16">
          {[
            ["1", "Find a quiet spot", "Even a closet works. No fans, no music, no traffic."],
            ["2", "Read 24 lines at your normal pace", "Each takes 6–20 seconds. Pause any time."],
            ["3", "Generate anything in your voice", "The voice stays on your device."],
          ].map(([n, t, d]) => (
            <div key={n} className="first-run-step">
              <div className="n">{n}</div>
              <div>
                <div className="ttl">{t}</div>
                <div className="desc">{d}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="row gap-8 mt-24" style={{justifyContent:"flex-end"}}>
          <button className="btn btn--ghost">Later</button>
          <button className="btn btn--primary">Start <IcChevron size={14}/></button>
        </div>
      </div>
    </div>
  );
}

/* ===== Dark mode example ===== */
function StateDarkGenerate() {
  return (
    <FrameShell activeId="v_main" activeTab="generate" theme="dark">
      <div className="page-inner" style={{padding: "32px 36px"}}>
        <div className="eyebrow">Digital voice clone</div>
        <h1 className="page-title" style={{fontSize: 42, letterSpacing:"-1px"}}>Make your voice say anything</h1>
        <p className="page-lede">Type any text. Generate it in your voice. Adjust pace, warmth, and breathing.</p>
        <div className="compose-shell mt-24">
          <div className="compose-input-wrap">
            <div style={{fontSize: 16, color:"var(--color-ink)"}}>
              I think the best thing about this neighborhood is how the bakery on the corner makes the whole block smell like sourdough every morning around seven.
            </div>
          </div>
          <div className="compose-toolbar">
            <div className="compose-tools-left">
              <span className="voice-pill"><VoiceMark hash={0x91c2} size={20}/><span>Calm Reading</span><IcChevronDown size={12}/></span>
            </div>
            <button className="btn btn--primary"><IcSparkles size={14}/>Generate</button>
          </div>
        </div>
        <div className="player mt-24">
          <div className="player-head">
            <div className="row gap-12">
              <span className="player-eyebrow">Result</span>
              <div className="row gap-8" style={{color:"var(--color-on-dark)"}}><VoiceMark hash={0x91c2} size={16}/><span style={{fontSize: 13}}>Calm Reading</span></div>
            </div>
            <span className="player-time">0:04 / 0:11</span>
          </div>
          <StaticWaveform seed={0xfa90} bars={100} height={70} played={0.4}/>
          <div className="player-controls">
            <div className="player-controls-left">
              <button className="play-btn"><IcPause size={16}/></button>
              <div className="speed-group">
                {[1, 1.25, 1.5, 2].map(s => <button key={s} className={`speed-btn ${s === 1 ? "active" : ""}`}>{s}×</button>)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </FrameShell>
  );
}

/* ===== Voice fingerprint specimen ===== */
function StateFingerprints() {
  const samples = [0x4a7d, 0x91c2, 0x2b5e, 0xd83a, 0x6c1a, 0x7a21, 0xfa90, 0x1c44, 0xb237, 0xc05a, 0x3e7e, 0x88a1];
  return (
    <div style={{padding: 40, height:"100%", background:"var(--color-canvas)", overflow:"hidden"}}>
      <div className="eyebrow">Generative voice fingerprint</div>
      <h1 className="page-title md" style={{fontSize: 36}}>Every voice gets its own mark</h1>
      <p className="page-lede" style={{maxWidth: 520}}>Each voice is rendered from a deterministic hash — 36 radial spokes whose amplitudes encode the voice's identity. Status color signals readiness.</p>
      <div style={{display:"grid", gridTemplateColumns:"repeat(4, 1fr)", gap: 32, marginTop: 40}}>
        {samples.map((h, i) => (
          <div key={h} style={{display:"flex", flexDirection:"column", alignItems:"center", gap: 12}}>
            <div style={{width: 96, height: 96, padding: 12, background: i % 3 === 0 ? "var(--color-surface-dark)" : "var(--color-surface-card)", borderRadius: 16, display:"flex", alignItems:"center", justifyContent:"center"}}>
              <VoiceMark hash={h} size={72} status={i % 3 === 1 ? "building" : "ready"} color={i % 3 === 0 ? "#fff" : undefined}/>
            </div>
            <div style={{fontFamily:"var(--font-mono)", fontSize: 11, color:"var(--color-muted)"}}>0x{h.toString(16)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ===== Recent generations list ===== */
function StateRecent() {
  return (
    <FrameShell activeId="v_main" activeTab="generate">
      <div className="page-inner" style={{padding: "32px 36px"}}>
        <div className="row between" style={{alignItems:"end", marginBottom: 14}}>
          <h2 style={{fontFamily:"var(--font-display)", fontWeight: 400, fontSize: 30, letterSpacing:"-0.5px", margin: 0}}>Recent generations</h2>
          <div className="row gap-8">
            <button className="btn btn--ghost btn--sm">Filter</button>
            <button className="btn btn--ghost btn--sm">Sort</button>
          </div>
        </div>
        <div className="subtabs" style={{marginTop: 0}}>
          <button className="subtab active">All · 47</button>
          <button className="subtab">Favorites · 8</button>
          <button className="subtab">Shared · 3</button>
        </div>
        <div style={{marginTop: 8}}>
          {sampleGenerations.map(g => {
            const v = sampleVoices.find(x => x.name === g.voice);
            return (
              <div key={g.id} className="recent-row">
                <button className="dark-icon-btn" style={{background:"var(--color-surface-soft)", color:"var(--color-ink)"}}><IcPlay size={14}/></button>
                <div style={{minWidth: 0}}>
                  <div className="recent-text">{g.text}</div>
                  <div className="recent-meta">
                    {v && <span className="row gap-6"><VoiceMark hash={v.hash} size={14}/>{g.voice}</span>}
                    <span className="dot"/><span>{g.timestamp}</span>
                    <span className="dot"/><span>{g.duration}s</span>
                  </div>
                </div>
                <MiniWaveform seed={g.seed} bars={22} height={24}/>
              </div>
            );
          })}
        </div>
      </div>
    </FrameShell>
  );
}

/* ============== Root canvas ============== */
function CanvasApp() {
  const W = 1280, H = 820;
  return (
    <DesignCanvas>
      <DCSection id="build" title="Build your voice" subtitle="Five states as the voice grows from nothing to ready">
        <DCArtboard id="build-empty" label="1 · Empty" width={W} height={H}><StateBuildEmpty/></DCArtboard>
        <DCArtboard id="build-rec" label="2 · Recording" width={W} height={H}><StateBuildRecording/></DCArtboard>
        <DCArtboard id="build-rev" label="3 · Reviewing" width={W} height={H}><StateBuildReviewing/></DCArtboard>
        <DCArtboard id="build-ready" label="4 · Voice ready" width={W} height={H}><StateBuildReady/></DCArtboard>
        <DCArtboard id="build-yt" label="5 · YouTube import" width={W} height={H}><StateImportYouTube/></DCArtboard>
      </DCSection>

      <DCSection id="generate" title="Generate" subtitle="Composer, player, recent">
        <DCArtboard id="gen-main" label="Composer · result" width={W} height={H}><StateGenerate/></DCArtboard>
        <DCArtboard id="gen-recent" label="Recent generations" width={W} height={H}><StateRecent/></DCArtboard>
        <DCArtboard id="gen-dark" label="Dark mode" width={W} height={H}><StateDarkGenerate/></DCArtboard>
      </DCSection>

      <DCSection id="audiobook" title="Audiobook" subtitle="Library and chapter-level reader">
        <DCArtboard id="ab-lib" label="Library" width={W} height={H}><StateAudiobookLibrary/></DCArtboard>
        <DCArtboard id="ab-read" label="Reader · queue" width={W} height={H}><StateAudiobookReader/></DCArtboard>
      </DCSection>

      <DCSection id="system" title="System details" subtitle="Onboarding modal and the voice-fingerprint specimen">
        <DCArtboard id="sys-onb" label="First-run modal" width={W} height={H}><StateFirstRun/></DCArtboard>
        <DCArtboard id="sys-marks" label="Voice fingerprints" width={W} height={H}><StateFingerprints/></DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

const root = ReactDOM.createRoot(document.getElementById("app"));
root.render(<CanvasApp/>);
