/* Build my voice — adaptive page driven by the active voice's status.
   States: empty / importing / recording / reviewing / ready. */

const { useEffect, useMemo, useRef, useState } = React;

function statusDotClass(s) { return `line-status-dot ${s}`; }

/* ------- Phoneme coverage card (dark, used inside recording state) ------- */
function PhonemeCoverage({ coverage, recent, dense = false }) {
  const t = useT();
  return (
    <div>
      <div className="row between" style={{marginBottom: 12}}>
        <span className="player-eyebrow">{t("phon.title")}</span>
        <span className="player-time">{Object.values(coverage).filter(v => v > 0).length} / {phonemes.length}</span>
      </div>
      <div className="phoneme-row">
        {phonemes.map(p => {
          const c = coverage[p] || 0;
          const cls = c >= 6 ? "covered-3" : c >= 3 ? "covered-2" : c >= 1 ? "covered" : "";
          const isRecent = recent && recent.includes(p);
          return (
            <span key={p} className={`phoneme-cell ${cls} ${isRecent ? "recent" : ""}`}>{p}</span>
          );
        })}
      </div>
      <div className="row gap-16 mt-16">
        <div className="row gap-6" style={{color: "var(--color-on-dark-soft)", fontSize: 12}}>
          <span className="phoneme-cell" style={{width:14, height:14, background:"rgba(93,184,166,0.55)"}}/> {t("phon.legend.strong")}
        </div>
        <div className="row gap-6" style={{color: "var(--color-on-dark-soft)", fontSize: 12}}>
          <span className="phoneme-cell" style={{width:14, height:14, background:"rgba(93,184,166,0.18)"}}/> {t("phon.legend.light")}
        </div>
        <div className="row gap-6" style={{color: "var(--color-on-dark-soft)", fontSize: 12}}>
          <span className="phoneme-cell" style={{width:14, height:14, background:"rgba(255,255,255,0.05)"}}/> {t("phon.legend.missing")}
        </div>
      </div>
    </div>
  );
}

/* ------- Recording stage shown when active voice is mid-recording -------- */
function RecordingStage({ line, lineNum, totalLines, onStop, onSkip, onRedo, isLive = true }) {
  const t = useT();
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    if (!isLive) return;
    const timer = setInterval(() => setElapsed(e => e + 0.1), 100);
    return () => clearInterval(timer);
  }, [isLive]);
  const fmt = (s) => {
    const m = Math.floor(s / 60); const r = Math.floor(s % 60);
    return `${m}:${String(r).padStart(2, "0")}`;
  };
  return (
    <div className="rec-stage">
      <div className="row between" style={{marginBottom: 18}}>
        <div className="eyebrow" style={{color: "var(--color-primary)", margin: 0}}>{t("rec.eyebrow", { n: lineNum, total: totalLines })}</div>
        <div className="row gap-8" style={{color: "var(--color-on-dark-soft)", fontSize: 13}}>
          <span className="kbd" style={{background: "rgba(255,255,255,0.06)", borderColor: "rgba(255,255,255,0.1)", color:"var(--color-on-dark-soft)"}}>{t("rec.spaceKey")}</span>
          <span>{t("rec.stopHint")}</span>
        </div>
      </div>
      <div className="rec-line">{line.text}</div>

      <LiveWaveform active={isLive} bars={80} height={88}/>

      <div className="rec-controls">
        <div className="row gap-16">
          <button className="rec-btn recording" onClick={onStop} title="Stop">
            <IcSquare size={22}/>
          </button>
          <div>
            <div className="rec-timer">{fmt(elapsed)} <span style={{opacity:0.5}}> · {t("rec.timerHint")}</span></div>
            <div style={{fontFamily:"var(--font-body)", fontSize:12, color:"var(--color-on-dark-soft)", marginTop: 4}}>
              {t("rec.coach")}
            </div>
          </div>
        </div>
        <div className="row gap-8">
          <button className="dark-link-btn" onClick={onRedo}><IcRotate size={14}/> {t("rec.redo")}</button>
          <button className="dark-link-btn" onClick={onSkip}>{t("rec.skip")} <IcChevron size={14}/></button>
        </div>
      </div>
    </div>
  );
}

/* ------- Importing stage (for YouTube / upload sources) ------------------ */
function ImportingStage({ voice, onCancel }) {
  const t = useT();
  const [step, setStep] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setStep(s => (s + 1) % 4), 1400);
    return () => clearInterval(id);
  }, []);
  const steps = ["build.importing.step1", "build.importing.step2", "build.importing.step3"];
  return (
    <div className="rec-stage" style={{padding: 28}}>
      <div className="row gap-12" style={{marginBottom: 18}}>
        <div className="eyebrow" style={{color: "var(--color-primary)", margin: 0}}>
          {voice.source === "yt" ? <><IcYoutube size={14} style={{verticalAlign:"middle"}}/> {t("build.source.yt")}</> :
           voice.source === "upload" ? <><IcUpload size={14} style={{verticalAlign:"middle"}}/> {t("build.source.upload")}</> :
           t("build.source.record")}
        </div>
      </div>
      <div style={{
        fontFamily: "var(--font-display)", fontWeight: 400,
        fontSize: 26, lineHeight: 1.25, letterSpacing: "-0.4px",
        color: "var(--color-on-dark)", marginBottom: 18,
      }}>
        {voice.sourceUrl || "https://www.youtube.com/watch?v=…"}
      </div>
      <LiveWaveform active={true} bars={70} height={64}/>
      <div className="mt-24" style={{display:"flex", flexDirection: "column", gap: 10}}>
        {steps.map((key, i) => {
          const done = i < step;
          const active = i === step;
          return (
            <div key={key} className="row gap-12" style={{
              opacity: i > step ? 0.4 : 1,
              fontSize: 14, color: "var(--color-on-dark)",
            }}>
              <span style={{
                width: 18, height: 18, borderRadius: "50%",
                background: done ? "var(--color-success)" : active ? "var(--color-primary)" : "rgba(255,255,255,0.08)",
                display: "inline-flex", alignItems: "center", justifyContent: "center",
                flexShrink: 0,
              }}>
                {done && <IcCheck size={12} style={{color: "#fff"}}/>}
                {active && <span style={{width: 6, height: 6, borderRadius: "50%", background:"#fff", animation: "pulse 1.4s ease-in-out infinite"}}/>}
              </span>
              <span>{t(key)}</span>
            </div>
          );
        })}
      </div>
      <div className="row between mt-24">
        <span style={{fontSize: 12, fontFamily: "var(--font-mono)", color:"var(--color-on-dark-soft)"}}>
          ~12s
        </span>
        <button className="dark-link-btn" onClick={onCancel}>{t("build.importing.cancel")}</button>
      </div>
    </div>
  );
}

/* ------- Per-state header strip ----------------------------------------- */
function StatusPanel({ state, voice, lineCount, totalLines, onPrimary, onSecondary }) {
  const t = useT();
  if (state === "empty") {
    return (
      <div className="build-status">
        <div className="build-status-content">
          <div className="build-status-title">{t("build.status.empty.title", { name: voice.name })}</div>
          <div className="build-status-sub">{t("build.status.empty.sub")}</div>
        </div>
        <div className="build-cta">
          <button className="btn btn--primary btn--lg" onClick={onPrimary}><IcMic size={16}/>{t("build.status.empty.start")}</button>
        </div>
      </div>
    );
  }
  if (state === "reviewing") {
    const pct = lineCount / totalLines;
    const subKey = lineCount > totalLines - 4 ? "build.status.reviewing.sub.near" : "build.status.reviewing.sub.far";
    return (
      <div className="build-status">
        <div className="build-status-content">
          <div className="coverage-meta">
            <Donut value={pct} size={64} stroke={6} color="var(--color-ink)" track="var(--color-hairline)" label={`${Math.round(pct*100)}%`}/>
            <div style={{minWidth: 0}}>
              <div className="build-status-title">{t("build.status.reviewing.title", { n: totalLines - lineCount })}</div>
              <div className="build-status-sub">{t(subKey)}</div>
            </div>
          </div>
        </div>
        <div className="build-cta">
          <button className="btn btn--secondary" onClick={onSecondary}>{t("build.status.reviewing.pause")}</button>
          <button className="btn btn--primary btn--lg" onClick={onPrimary}><IcMic size={16}/>{t("build.status.reviewing.continue")}</button>
        </div>
      </div>
    );
  }
  // ready
  return (
    <div className="build-status ready">
      <div className="build-status-content">
        <div className="coverage-meta">
          <Donut value={1} size={64} stroke={6} color="#fff" track="rgba(255,255,255,0.25)" label={<IcCheck size={20} style={{color:"#fff"}}/>}/>
          <div style={{minWidth: 0}}>
            <div className="build-status-title">{t("build.status.ready.title")}</div>
            <div className="build-status-sub">{t("build.status.ready.sub")}</div>
          </div>
        </div>
      </div>
      <div className="build-cta">
        <button className="btn btn--ghost" style={{color:"#fff"}} onClick={onSecondary}>{t("build.status.ready.listen")}</button>
        <button className="btn btn--secondary btn--lg" onClick={onPrimary}>{t("build.status.ready.generate")} <IcChevron size={16}/></button>
      </div>
    </div>
  );
}

/* ------- Lines list — each row shows a mini speech waveform -------------- */
function LinesList({ lines, currentId, onPick, onRedo, voiceHash }) {
  return (
    <div className="lines-list">
      {lines.map(L => (
        <div key={L.id} className={`line-row ${currentId === L.id ? "active" : ""}`} onClick={() => onPick(L.id)}>
          <div className="row gap-12" style={{alignItems:"center"}}>
            <span className="line-num">{String(L.id).padStart(2,"0")}</span>
            <span className={statusDotClass(L.status)}/>
          </div>
          <div className="line-text">{L.text}</div>
          <div className="line-actions">
            {L.status !== "todo" && L.status !== "recording" && (
              <MiniWaveform
                seed={(voiceHash || 0) ^ L.id * 137}
                text={L.text}
                duration={L.duration}
                bars={28}
                height={20}
                color={L.status === "fail" ? "var(--color-error)" : L.status === "retry" ? "var(--color-warning)" : "var(--color-muted-soft)"}
              />
            )}
            <span className="line-meta">{L.duration.toFixed(1)}s</span>
            {L.status !== "todo" && L.status !== "recording" && (
              <>
                <button className="icon-btn" title="Play" onClick={e => e.stopPropagation()}><IcPlay size={14}/></button>
                <button className="icon-btn" title="Re-record" onClick={(e) => {e.stopPropagation(); onRedo && onRedo(L.id);}}><IcRotate size={14}/></button>
              </>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ------- Main BuildPage ------------------------------------------------- */
function BuildPage({ activeVoice, onChangeTab, onUpdateVoice }) {
  const t = useT();
  const totalLines = 24;
  const [mode, setMode] = useState(null); // null | "recording"
  const [currentLineId, setCurrentLineId] = useState(null);

  // Lines, with quality status derived from speech analysis
  const lines = useMemo(() => {
    const progressCount = activeVoice.lineCount;
    return sampleLines.map((L, i) => {
      const seed = (activeVoice.hash || 0) ^ (L.id * 137);
      const quality = speechQuality(seed, L.text, L.duration);
      let status;
      if (activeVoice.status === "ready") status = quality.status;
      else if (activeVoice.status === "empty") status = "todo";
      else if (activeVoice.status === "importing") status = "todo";
      else status = i < progressCount ? quality.status : "todo";
      return { ...L, status };
    });
  }, [activeVoice]);

  const firstTodo = lines.find(L => L.status === "todo");
  const recordingLine = useMemo(() => {
    if (mode !== "recording") return null;
    const lineId = currentLineId || (firstTodo && firstTodo.id);
    return lines.find(L => L.id === lineId) || firstTodo;
  }, [mode, currentLineId, lines, firstTodo]);

  /* Phoneme coverage scales with progress */
  const coverage = useMemo(() => {
    const max = activeVoice.status === "ready" ? 24 : activeVoice.lineCount;
    return buildCoverage(activeVoice.hash + activeVoice.lineCount, max);
  }, [activeVoice]);

  /* Auto-advance simulated importing state */
  useEffect(() => {
    if (activeVoice.status === "importing") {
      const t1 = setTimeout(() => {
        onUpdateVoice && onUpdateVoice(activeVoice.id, { status: "ready", lineCount: totalLines });
      }, 4200);
      return () => clearTimeout(t1);
    }
  }, [activeVoice.status, activeVoice.id]);

  const startRecording = () => { setMode("recording"); setCurrentLineId(firstTodo ? firstTodo.id : 1); };
  const stopRecording = () => {
    if (recordingLine) {
      const next = lines.find(L => L.id > recordingLine.id && L.status === "todo");
      if (next) {
        onUpdateVoice && onUpdateVoice(activeVoice.id, { lineCount: Math.min(totalLines, activeVoice.lineCount + 1) });
        setCurrentLineId(next.id);
      } else {
        setMode(null);
      }
    } else setMode(null);
  };

  /* State decisioning */
  let state;
  if (activeVoice.status === "importing") state = "importing";
  else if (mode === "recording") state = "recording";
  else if (activeVoice.status === "ready") state = "ready";
  else if (activeVoice.status === "empty") state = "empty";
  else state = "reviewing";

  return (
    <div className="page-inner">
      <div className="eyebrow">{t("build.eyebrow")}</div>
      <div className="row between" style={{alignItems:"end"}}>
        <h1 className="page-title">
          {state === "empty" ? t("build.title.empty")
           : state === "importing" ? t("build.title.importing")
           : state === "recording" ? t("build.title.recording")
           : state === "reviewing" ? t("build.title.reviewing")
           : t("build.title.ready")}
        </h1>
        {state !== "importing" && (
          <div className="row gap-8" style={{marginBottom: 24}}>
            <button className="btn btn--ghost btn--sm"><IcEdit size={14}/>{t("build.action.rename")}</button>
            <button className="btn btn--ghost btn--sm"><IcDownload size={14}/>{t("build.action.export")}</button>
            <button className="btn btn--ghost btn--sm" style={{color: "var(--color-error)"}}><IcTrash size={14}/>{t("build.action.delete")}</button>
          </div>
        )}
      </div>
      <p className="page-lede">
        {state === "empty" ? t("build.lede.empty")
         : state === "importing" ? t("build.lede.importing")
         : state === "recording" ? t("build.lede.recording")
         : state === "reviewing" ? t("build.lede.reviewing")
         : t("build.lede.ready")}
      </p>

      {/* Top status panel */}
      <div className="mt-32">
        {state === "importing" && <ImportingStage voice={activeVoice} onCancel={() => onUpdateVoice && onUpdateVoice(activeVoice.id, { status: "empty" })}/>}
        {state !== "recording" && state !== "importing" && (
          <StatusPanel
            state={state}
            voice={activeVoice}
            lineCount={activeVoice.lineCount}
            totalLines={totalLines}
            onPrimary={() => state === "ready" ? onChangeTab("generate") : startRecording()}
            onSecondary={() => {}}
          />
        )}
        {state === "recording" && recordingLine && (
          <RecordingStage
            line={recordingLine}
            lineNum={lines.findIndex(L => L.id === recordingLine.id) + 1}
            totalLines={totalLines}
            onStop={stopRecording}
            onSkip={() => {
              const next = lines.find(L => L.id > recordingLine.id && L.status === "todo");
              if (next) setCurrentLineId(next.id); else setMode(null);
            }}
            onRedo={() => {}}
          />
        )}
      </div>

      {/* Lines + coverage */}
      {(state === "ready" || state === "reviewing" || state === "recording") && (
        <div style={{display:"grid", gridTemplateColumns: state === "recording" ? "1fr 320px" : "1fr", gap: 32, marginTop: 32, alignItems: "start"}}>
          <div>
            <div className="row between mt-8" style={{alignItems:"center"}}>
              <h6 style={{margin:0, fontFamily: "var(--font-body)", fontWeight: 500, color: "var(--color-ink)", textTransform: "uppercase", letterSpacing: 1.2, fontSize: 11}}>
                {state === "ready" ? t("lines.allRecorded") : t("lines.progress", { n: activeVoice.lineCount, total: totalLines })}
              </h6>
              <div className="row gap-16">
                <span className="row gap-6" style={{fontSize: 12, color: "var(--color-muted)"}}>
                  <span className="line-status-dot pass"/> {t("lines.legend.pass")}
                </span>
                <span className="row gap-6" style={{fontSize: 12, color: "var(--color-muted)"}}>
                  <span className="line-status-dot retry"/> {t("lines.legend.retry")}
                </span>
                <span className="row gap-6" style={{fontSize: 12, color: "var(--color-muted)"}}>
                  <span className="line-status-dot fail"/> {t("lines.legend.fail")}
                </span>
              </div>
            </div>
            <LinesList
              lines={lines}
              voiceHash={activeVoice.hash}
              currentId={recordingLine && recordingLine.id}
              onPick={(id) => { setCurrentLineId(id); }}
              onRedo={(id) => { setMode("recording"); setCurrentLineId(id); }}
            />
          </div>
          {state === "recording" && (
            <div className="card-dark" style={{position: "sticky", top: 24}}>
              <PhonemeCoverage coverage={coverage} recent={recordingLine ? ["ʃ","ɛ","r","ə"] : []}/>
            </div>
          )}
        </div>
      )}

      {state === "empty" && (
        <div className="empty-zone mt-48">
          <div className="ill"><IcMic size={24}/></div>
          <h3>{t("empty.title")}</h3>
          <p>{t("empty.sub")}</p>
          <div className="row gap-12 mt-8">
            <button className="btn btn--primary" onClick={startRecording}><IcMic size={14}/>{t("empty.btn.record")}</button>
          </div>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { BuildPage });
