/* Audiobook: library + reader view with chapter queue + sticky player bar */

const { useEffect, useMemo, useRef, useState } = React;

function BookCover({ book, size = "card" }) {
  const Spike = window.SpikeIcon;
  return (
    <div className="book-cover" style={{ background: book.cover.bg }}>
      <SpikeIcon className="book-cover-mark" style={{ color: book.cover.accent }}/>
      <div className="title-zh">{book.title}</div>
    </div>
  );
}

function BookCard({ book, onOpen }) {
  const pct = book.progressSegments / book.totalSegments;
  return (
    <div className="book-card" onClick={() => onOpen(book.id)}>
      <BookCover book={book}/>
      <div>
        <div className="book-title">{book.title}</div>
        <div className="book-author">{book.author}</div>
      </div>
      <div>
        <Progress value={pct}/>
        <div className="progress-meta mt-8">
          <span>{book.progressSegments} / {book.totalSegments}</span>
          <span>{Math.round(pct * 100)}%</span>
        </div>
      </div>
    </div>
  );
}

function BookLibrary({ books, onOpen, onUpload, voices, activeVoice }) {
  const t = useT();
  return (
    <div className="page-inner wide">
      <div className="eyebrow">{t("ab.eyebrow")}</div>
      <div className="row between" style={{alignItems:"end"}}>
        <h1 className="page-title md">{t("ab.title")}</h1>
        <div className="row gap-8" style={{marginBottom: 16}}>
          <div className="voice-pill">
            <div className="vm-wrap" style={{width: 22, height: 22}}>
              <VoiceMark hash={activeVoice.hash} size={22}/>
            </div>
            <span>{activeVoice.name}</span>
            <IcChevronDown size={14}/>
          </div>
        </div>
      </div>
      <p className="page-lede">{t("ab.lede")}</p>

      <div style={{display:"grid", gridTemplateColumns: "1.4fr 1fr", gap: 24, marginTop: 40, alignItems:"start"}}>
        <div>
          <h6 style={{fontSize: 11, fontFamily: "var(--font-body)", fontWeight: 500, color: "var(--color-muted)", textTransform: "uppercase", letterSpacing: 1.2, margin: "0 0 14px"}}>
            {t("ab.section.inProgress")}
          </h6>
          <div className="book-grid">
            {books.map(b => <BookCard key={b.id} book={b} onOpen={onOpen}/>)}
            <button className="book-upload-card" onClick={onUpload}>
              <IcUpload size={20}/>
              <div style={{fontFamily: "var(--font-body)", fontSize: 14, fontWeight: 500, color: "var(--color-ink)"}}>{t("ab.upload.title")}</div>
              <div style={{fontFamily: "var(--font-body)", fontSize: 12, color: "var(--color-muted)"}}>{t("ab.upload.sub")}</div>
            </button>
          </div>
        </div>
        <div className="card-cream" style={{padding: 24}}>
          <div className="eyebrow" style={{marginBottom: 8}}>{t("ab.howItWorks.eyebrow")}</div>
          <h5 style={{margin:0, fontFamily: "var(--font-display)", fontWeight: 400, fontSize: 22, letterSpacing: "-0.3px"}}>{t("ab.howItWorks.title")}</h5>
          <div className="mt-16" style={{display:"flex", flexDirection:"column", gap: 14}}>
            {[
              ["01", t("ab.howItWorks.step1.title"), t("ab.howItWorks.step1.desc")],
              ["02", t("ab.howItWorks.step2.title"), t("ab.howItWorks.step2.desc")],
              ["03", t("ab.howItWorks.step3.title"), t("ab.howItWorks.step3.desc")],
            ].map(([n, ti, d]) => (
              <div key={n} style={{display:"grid", gridTemplateColumns: "32px 1fr", gap: 12}}>
                <div style={{
                  fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--color-muted)",
                  background: "var(--color-canvas)", borderRadius: 999, padding: "4px 0",
                  width: 30, height: 22, display:"flex", alignItems:"center", justifyContent:"center",
                  border: "1px solid var(--color-hairline)",
                }}>{n}</div>
                <div>
                  <div style={{fontFamily: "var(--font-body)", fontSize: 14, fontWeight: 500, color: "var(--color-ink)"}}>{ti}</div>
                  <div style={{fontFamily: "var(--font-body)", fontSize: 13, color: "var(--color-muted)", marginTop: 2}}>{d}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* Reader for a single book */
function BookReader({ book, voices, onBack, onChangeTab }) {
  const t = useT();
  const [activeChId, setActiveChId] = useState(book.chapters.find(c => c.status === "ready").id);
  const ch = book.chapters.find(c => c.id === activeChId);
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState(0.32);
  const v = voices.find(x => x.name === book.voice);
  const fmt = (s) => {
    const m = Math.floor(s / 60);
    const r = Math.floor(s % 60);
    return `${m}:${String(r).padStart(2,"0")}`;
  };
  const totalSec = (ch && ch.segCount) ? ch.segCount * 8 : 600;

  return (
    <div className="page-inner wide">
      <div className="row gap-8" style={{marginBottom: 14}}>
        <button className="btn btn--ghost btn--sm" onClick={onBack}>
          <IcChevronLeft size={14}/> {t("ab.backToAll")}
        </button>
      </div>

      <div className="reader-shell">
        <aside className="reader-chapters">
          <div className="ch-head">{t("ab.chapters")}</div>
          {book.chapters.map(c => (
            <div key={c.id} className={`chapter-item ${activeChId === c.id ? "active" : ""}`} onClick={() => c.status !== "queued" && setActiveChId(c.id)}>
              <span className="ch-num">{String(c.id).padStart(2,"0")}</span>
              <span className="ch-title">{c.title}</span>
              <span className={`ch-status ${c.status}`}/>
            </div>
          ))}
          <div style={{marginTop: 18}}>
            <div className="queue-card">
              <div className="queue-head">
                <span className="player-eyebrow">{t("ab.queue.title")}</span>
                <span style={{fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--color-on-dark-soft)"}}>{t("ab.queue.count", { done: 4, total: 7 })}</span>
              </div>
              {book.chapters.slice(3, 7).map((c, i) => (
                <div key={c.id} className="queue-row">
                  <span className="q-num">{String(c.id).padStart(2,"0")}</span>
                  <span className="q-title">{c.title}</span>
                  <span className="q-status">
                    {c.status === "gen" && <><span className="gen-dot"/>{Math.round(c.segCount > 0 ? 35 : 0)}%</>}
                    {c.status === "queued" && <><span className="queued-dot"/>{t("ab.queue.queued")}</>}
                    {c.status === "ready" && <><span className="ok-dot"/>{t("ab.queue.ready")}</>}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </aside>

        <div className="reader-body">
          <div className="book-hero">
            <BookCover book={book}/>
            <div>
              <div className="eyebrow">{book.author}</div>
              <h2>{book.title}</h2>
              <p style={{fontFamily: "var(--font-body)", fontSize: 14, color: "var(--color-muted)", margin: "0 0 14px"}}>{book.subtitle}</p>
              <div className="row gap-12">
                <span className="badge"><IcCheck size={12} style={{marginRight: 4}}/>{t("ab.badge.ready", { n: book.chapters.filter(c => c.status === "ready").length })}</span>
                <span className="badge" style={{background:"var(--color-canvas)", border:"1px solid var(--color-hairline)"}}>
                  <span className="ch-status gen" style={{marginRight:6, width:7, height:7, borderRadius:"50%", background:"var(--color-warning)", animation:"pulse 1.4s ease-in-out infinite", display:"inline-block"}}/>
                  {t("ab.badge.generating")}
                </span>
                <span className="badge" style={{background:"var(--color-canvas)", border:"1px solid var(--color-hairline)"}}>
                  {t("ab.badge.queued", { n: book.chapters.filter(c => c.status === "queued").length })}
                </span>
              </div>
            </div>
          </div>

          {/* Now playing chapter card */}
          <div className="card-cream" style={{padding: 24, marginBottom: 20}}>
            <div className="row between" style={{alignItems:"start", marginBottom: 16}}>
              <div>
                <div className="eyebrow" style={{margin: 0, color: "var(--color-primary)"}}>{t("ab.nowPlaying")}</div>
                <h5 style={{fontFamily: "var(--font-display)", fontWeight: 400, fontSize: 28, letterSpacing:"-0.4px", margin: "6px 0 4px"}}>
                  {t("ab.chapter", { n: ch.id, title: ch.title })}
                </h5>
                <div style={{fontFamily: "var(--font-body)", fontSize: 13, color: "var(--color-muted)"}}>
                  {t("ab.chapterMeta", { segs: ch.segCount, time: fmt(totalSec) })}
                </div>
              </div>
              <div className="row gap-8">
                <button className="icon-btn"><IcDownload size={16}/></button>
                <button className="icon-btn"><IcShare size={16}/></button>
                <button className="icon-btn"><IcRotate size={16}/></button>
              </div>
            </div>

            <div style={{background: "var(--color-surface-dark)", borderRadius: 12, padding: 20}}>
              <StaticWaveform seed={book.id.charCodeAt(0) + ch.id * 71} bars={140} height={64} played={pos} duration={totalSec}/>
              <div className="row between mt-8" style={{color: "var(--color-on-dark-soft)", fontSize: 12, fontFamily: "var(--font-mono)"}}>
                <span>{fmt(pos * totalSec)}</span>
                <span>{fmt(totalSec)}</span>
              </div>
            </div>

            <div className="row between mt-16">
              <div className="row gap-8">
                <button className="btn btn--ghost btn--sm"><IcSkipBack size={14}/>{t("ab.btn.prev")}</button>
                <button className="btn btn--primary" onClick={() => setPlaying(p => !p)}>
                  {playing ? <><IcPause size={14}/>{t("ab.btn.pause")}</> : <><IcPlay size={14}/>{t("ab.btn.play")}</>}
                </button>
                <button className="btn btn--ghost btn--sm">{t("ab.btn.next")}<IcSkipFwd size={14}/></button>
              </div>
              <div className="row gap-8">
                <span style={{fontSize: 12, color: "var(--color-muted)"}}>{t("ab.speed")}</span>
                <div className="speed-group" style={{background:"var(--color-canvas)", border:"1px solid var(--color-hairline)"}}>
                  {[1, 1.25, 1.5, 2].map(s => (
                    <button key={s} className={`speed-btn ${s === 1.25 ? "active" : ""}`}
                      style={{color: s === 1.25 ? "var(--color-on-primary)" : "var(--color-muted)"}}>{s}×</button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Transcript preview */}
          <div>
            <h6 style={{fontSize: 11, fontFamily: "var(--font-body)", fontWeight: 500, color: "var(--color-muted)", textTransform: "uppercase", letterSpacing: 1.2, margin: "8px 0 14px"}}>
              {t("ab.transcript", { n: 58, total: ch.segCount })}
            </h6>
            <div style={{display:"flex", flexDirection: "column", gap: 4}}>
              {[
                ["56", "細胞的分裂是一場古老的舞蹈，DNA 在當中既是樂譜，也是樂手。"],
                ["57", "Mitochondria, the small power plants inside every cell, carry their own DNA — a legacy from a billion-year-old bacterial ancestor."],
                ["58", "當這場舞蹈出錯，當粒線體的指揮失調，細胞便開始走向我們稱之為癌症的混亂。", true],
                ["59", "Otto Warburg noticed this in 1924: cancer cells preferred fermentation to respiration, even when oxygen was plentiful."],
                ["60", "His observation sat quietly for ninety years before a new generation of researchers returned to it."],
              ].map(([n, t, active]) => (
                <div key={n} style={{
                  display:"grid", gridTemplateColumns: "40px 1fr", gap: 16,
                  padding: "12px 14px",
                  borderRadius: 10,
                  background: active ? "var(--color-surface-cream-strong)" : "transparent",
                  cursor: "pointer",
                }}>
                  <span style={{fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--color-muted)"}}>{n}</span>
                  <span style={{fontFamily: "var(--font-body)", fontSize: 15, lineHeight: 1.55, color: active ? "var(--color-ink)" : "var(--color-body)", textWrap: "pretty"}}>{t}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Sticky player bar */}
      <div className="player-bar">
        <button className="play-btn" onClick={() => setPlaying(p => !p)}>
          {playing ? <IcPause size={16}/> : <IcPlay size={16}/>}
        </button>
        <div style={{minWidth: 0}}>
          <div className="pb-title">Chapter {ch.id} · {ch.title}</div>
          <div className="pb-time">{book.title} · {v && v.name} · {fmt(pos*totalSec)} / {fmt(totalSec)}</div>
        </div>
        <div className="pb-progress" style={{height: 4, background: "rgba(255,255,255,0.15)", borderRadius: 2, minWidth: 100}}>
          <div style={{width: `${pos*100}%`, height: "100%", background: "var(--color-primary)", borderRadius: 2}}/>
        </div>
      </div>
    </div>
  );
}

function AudiobookPage({ books, voices, activeVoice, onChangeTab }) {
  const [openId, setOpenId] = useState(null);
  if (openId) {
    const b = books.find(x => x.id === openId);
    return <BookReader book={b} voices={voices} onBack={() => setOpenId(null)} onChangeTab={onChangeTab}/>;
  }
  return <BookLibrary books={books} voices={voices} activeVoice={activeVoice} onOpen={setOpenId}/>;
}

Object.assign(window, { AudiobookPage });
