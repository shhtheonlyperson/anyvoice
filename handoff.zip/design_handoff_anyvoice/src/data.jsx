/* Sample data + state for the AnyVoice prototype */

const sampleVoices = [
  { id: "v_main", name: "我的聲音", subtitle: "Mandarin · ready", status: "ready", hash: 0x4a7d, lineCount: 24, totalLines: 24, lang: "zh-TW" },
  { id: "v_calm", name: "Calm Reading", subtitle: "English · ready", status: "ready", hash: 0x91c2, lineCount: 24, totalLines: 24, lang: "en-US" },
  { id: "v_pod", name: "Podcast voice", subtitle: "12 of 24 lines", status: "building", hash: 0x2b5e, lineCount: 12, totalLines: 24, lang: "en-US" },
  { id: "v_late", name: "Late-night", subtitle: "0 of 24 lines", status: "empty", hash: 0xd83a, lineCount: 0, totalLines: 24, lang: "en-US" },
];

/* Lines for the build flow.
   status: pass / retry / fail / todo / recording (set in app state)
   coverageDelta: phonemes contributed (informational) */
const sampleLines = [
  { id: 1, text: "她在窗邊讀著一封早就該回的信，光線正好。", duration: 7.4, status: "pass" },
  { id: 2, text: "Coffee was cold, but she kept holding the cup for the warmth memory of it.", duration: 8.1, status: "pass" },
  { id: 3, text: "三點半，地下室的影印機又卡住了。", duration: 5.9, status: "pass" },
  { id: 4, text: "It's not that I'm tired — it's that I forgot what rested feels like.", duration: 7.2, status: "retry" },
  { id: 5, text: "請說：「在下雨的星期二早上，我想喝熱可可。」", duration: 8.4, status: "pass" },
  { id: 6, text: "Five years from now, you won't remember the meeting, only the walk after.", duration: 8.0, status: "pass" },
  { id: 7, text: "他關上門的方式比說話的內容更誠實。", duration: 6.7, status: "pass" },
  { id: 8, text: "The library closed at nine; we stayed for the long way home.", duration: 6.4, status: "fail" },
  { id: 9, text: "他在便利商店的玻璃前看著自己的倒影，整理領子。", duration: 7.8, status: "pass" },
  { id: 10, text: "Read this with the unhurried pace of someone reading to a child.", duration: 7.0, status: "pass" },
  { id: 11, text: "請唸：「七、八、九、十。」", duration: 4.2, status: "pass" },
  { id: 12, text: "I told her the news in the same voice I use for the weather.", duration: 7.6, status: "pass" },
  { id: 13, text: "雨停了，柏油路上的氣味是夏天唯一不撒謊的東西。", duration: 8.9, status: "pass" },
  { id: 14, text: "Whisper now, like you're not sure anyone is listening but you hope someone is.", duration: 8.7, status: "retry" },
  { id: 15, text: "他笑得很短，但那是真的笑。", duration: 4.5, status: "pass" },
  { id: 16, text: "請以一般語氣說：「我會準時到的，別擔心。」", duration: 6.2, status: "pass" },
  { id: 17, text: "There's a kind of quiet that only old houses know how to keep.", duration: 7.1, status: "pass" },
  { id: 18, text: "她把鑰匙放回原來的位置，像什麼事都沒發生過。", duration: 6.8, status: "pass" },
  { id: 19, text: "Read with surprise, but kind surprise — the way you'd say \"oh, you came.\"", duration: 8.2, status: "pass" },
  { id: 20, text: "六月的風從窗縫鑽進來，把窗簾吹得像呼吸。", duration: 7.3, status: "pass" },
  { id: 21, text: "I'll be honest — I haven't read it. I just liked the cover.", duration: 6.0, status: "pass" },
  { id: 22, text: "請以朗讀的方式唸：「在那段日子裡，我們什麼都沒有，但什麼也都不缺。」", duration: 10.2, status: "pass" },
  { id: 23, text: "Pause between sentences. Let the room come back in.", duration: 6.4, status: "pass" },
  { id: 24, text: "我們明天見。", duration: 2.6, status: "pass" },
];

const sampleGenerations = [
  {
    id: "gen_atq8",
    text: "台積電是世界頂尖的半導體公司，多年來在世界競爭中持續領先，源自於我們有世界上最優秀的夥伴。 好的工作，不只給你好的福利待遇，更讓你與最厲害的人成為同事。",
    voice: "我的聲音",
    duration: 17,
    timestamp: "2 minutes ago",
    seed: 0x7a21,
  },
  {
    id: "gen_p4k9",
    text: "I think the best thing about this neighborhood is how the bakery on the corner makes the whole block smell like sourdough every morning around seven.",
    voice: "Calm Reading",
    duration: 11,
    timestamp: "14 minutes ago",
    seed: 0xfa90,
  },
  {
    id: "gen_m2x0",
    text: "今天台北的天氣陰陰的，傍晚有局部短暫陣雨。出門記得帶把折傘，地鐵站附近有小販。",
    voice: "我的聲音",
    duration: 9,
    timestamp: "Yesterday",
    seed: 0x1c44,
  },
  {
    id: "gen_lqo1",
    text: "Chapter one. The road from Greenwood to the lighthouse was longer than the map suggested, and quieter — the kind of quiet that asks questions of you.",
    voice: "Calm Reading",
    duration: 14,
    timestamp: "Yesterday",
    seed: 0xb237,
  },
  {
    id: "gen_e7nd",
    text: "新進員工請於下週一上午九點到三樓會議室報到，攜帶身份證正反面影本與一吋大頭照兩張。",
    voice: "我的聲音",
    duration: 12,
    timestamp: "Mar 17",
    seed: 0x9012,
  },
];

const sampleBooks = [
  {
    id: "b_cancer",
    title: "癌症的真相",
    subtitle: "The Truth About Cancer",
    author: "Travis Christofferson",
    cover: { bg: "#1f1e1b", accent: "var(--color-accent-amber)" },
    progressSegments: 363,
    totalSegments: 1717,
    voice: "我的聲音",
    chapters: [
      { id: 1, title: "Preface", segCount: 18, status: "ready" },
      { id: 2, title: "A Mutational Beginning", segCount: 142, status: "ready" },
      { id: 3, title: "Watson and the War on Cancer", segCount: 168, status: "ready" },
      { id: 4, title: "Otto's Theory", segCount: 35, status: "gen" },
      { id: 5, title: "Reviving the Metabolic Theory", segCount: 0, status: "queued" },
      { id: 6, title: "The Press-Pulse Protocol", segCount: 0, status: "queued" },
      { id: 7, title: "Where We Go From Here", segCount: 0, status: "queued" },
    ],
  },
  {
    id: "b_lin",
    title: "房思琪的初戀樂園",
    subtitle: "Fang Si-Chi's First Love Paradise",
    author: "林奕含",
    cover: { bg: "#2a2622", accent: "var(--color-primary)" },
    progressSegments: 453,
    totalSegments: 1844,
    voice: "我的聲音",
    chapters: [
      { id: 1, title: "樂園", segCount: 88, status: "ready" },
      { id: 2, title: "失樂園", segCount: 142, status: "ready" },
      { id: 3, title: "復樂園", segCount: 223, status: "ready" },
    ],
  },
];

/* Phonemes for the coverage tracker — IPA-ish subset */
const phonemes = [
  "i", "ɪ", "e", "ɛ", "æ", "ɑ", "ɔ", "o", "ʊ", "u", "ʌ", "ə",
  "aɪ", "aʊ", "ɔɪ", "eɪ", "oʊ",
  "p", "b", "t", "d", "k", "g",
  "f", "v", "θ", "ð", "s", "z", "ʃ", "ʒ", "h",
  "tʃ", "dʒ", "m", "n", "ŋ", "l", "r", "j", "w",
];
/* Lock in a coverage map (deterministic) — count of times each phoneme was recorded */
function buildCoverage(seed = 24, max = 24) {
  const map = {};
  let s = seed;
  for (let i = 0; i < phonemes.length; i++) {
    s = (s * 9301 + 49297) % 233280;
    const v = (s / 233280) * max;
    map[phonemes[i]] = Math.min(max, Math.floor(v * 0.9 + 0.6));
  }
  return map;
}

Object.assign(window, {
  sampleVoices, sampleLines, sampleGenerations, sampleBooks, phonemes, buildCoverage,
});
