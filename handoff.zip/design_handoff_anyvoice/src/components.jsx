/* Shared visual components: VoiceMark (generative voice fingerprint),
   Waveform (live + static), Donut, MiniDonut, RippleViz. */

const { useEffect, useMemo, useRef, useState } = React;

/* Deterministic pseudo-random based on seed */
function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0xffffffff;
  };
}

/* ------------------------------------------------------------------ *
 * Speech-like waveform generator.
 *
 * Real recorded speech follows a few rhythmic rules visible to the eye:
 *   - Syllables ~3-5/sec → bright peaks with valleys in between
 *   - Word boundaries → small dips
 *   - Commas/periods → brief silences
 *   - Phrase envelope: ramp-in, sustain, fall-off
 *   - Vowels (a/e/i/o/u, 中文母音) carry more energy than consonants
 *
 * We bake all of that into a deterministic generator so visuals stay
 * stable across renders but read as recorded speech, not random noise.
 * ------------------------------------------------------------------ */
function speechBars(seed, barCount, text = "", duration = null) {
  const rand = rng(seed || 1);
  // Estimate syllable count from text. CJK chars are 1 syllable each;
  // Latin words ≈ 1.4 syllables per word.
  let syllables;
  if (text) {
    const cjk = (text.match(/[\u3400-\u9fff]/g) || []).length;
    const latinWords = (text.match(/[a-z']+/gi) || []).length;
    syllables = Math.max(4, cjk + Math.round(latinWords * 1.4));
  } else if (duration) {
    syllables = Math.max(4, Math.round(duration * 3.2));
  } else {
    syllables = Math.max(6, Math.round(barCount / 6));
  }

  // Position of pauses (commas/periods). For text we anchor at real punctuation.
  // Each pause is a fraction (0-1) along the line.
  const pauses = [];
  if (text) {
    const len = text.length;
    for (let i = 0; i < len; i++) {
      const ch = text[i];
      if (/[,，、。.!?！？:]/.test(ch)) {
        const strength = /[。.!?！？]/.test(ch) ? 0.85 : 0.45;
        pauses.push({ pos: i / len, strength });
      }
    }
  } else {
    // Insert 1-2 pauses at slightly randomized positions
    const n = 1 + Math.floor(rand() * 2);
    for (let i = 0; i < n; i++) {
      pauses.push({ pos: 0.25 + (i + 1) * (0.6 / (n + 1)) + rand() * 0.1, strength: 0.55 });
    }
  }

  // Per-syllable centers along the [0, 1] axis, with slight irregularity
  const syllCenters = [];
  for (let i = 0; i < syllables; i++) {
    const base = (i + 0.5) / syllables;
    const jitter = (rand() - 0.5) * (0.6 / syllables);
    syllCenters.push(Math.max(0, Math.min(1, base + jitter)));
  }
  // Per-syllable peak amplitude (some emphasized, some quieter)
  const syllAmp = syllCenters.map(() => 0.55 + rand() * 0.45);
  const syllWidth = 1.0 / syllables * 0.42; // gaussian width

  const bars = new Array(barCount).fill(0);
  for (let b = 0; b < barCount; b++) {
    const x = b / (barCount - 1);
    // Phrase envelope — soft ramp-in, sustain, ramp-out
    const env = Math.min(
      1,
      Math.sin(Math.min(1, x / 0.12) * Math.PI / 2),
      Math.sin(Math.min(1, (1 - x) / 0.18) * Math.PI / 2)
    );
    // Sum of gaussian syllable peaks
    let v = 0;
    for (let i = 0; i < syllCenters.length; i++) {
      const d = x - syllCenters[i];
      v += syllAmp[i] * Math.exp(-(d * d) / (2 * syllWidth * syllWidth));
    }
    // Apply pauses — they suppress amplitude in a narrow window
    for (let i = 0; i < pauses.length; i++) {
      const d = Math.abs(x - pauses[i].pos);
      if (d < 0.04) {
        const f = 1 - pauses[i].strength * (1 - d / 0.04);
        v *= f;
      }
    }
    // Tiny consonant noise between peaks adds texture
    v += (rand() - 0.5) * 0.08;
    bars[b] = Math.max(0.03, env * Math.min(1, v));
  }
  return bars;
}

/* Quality assessment that visually corresponds to the waveform.
   Returns: { status, score, snr, peakRatio } */
function speechQuality(seed, text, duration) {
  const bars = speechBars(seed, 60, text, duration);
  const mean = bars.reduce((a, b) => a + b, 0) / bars.length;
  const peak = Math.max(...bars);
  const minimum = Math.min(...bars);
  const peakRatio = peak / Math.max(0.01, mean);
  // dynamic range — too low means flat, too high means uneven
  const range = peak - minimum;

  let score = 0.85;
  if (mean < 0.3) score -= 0.25;                  // too quiet
  if (peakRatio > 3.4) score -= 0.20;             // peaky / clipping vibe
  if (range < 0.35) score -= 0.18;                // flat
  if (duration && (duration < 4 || duration > 22)) score -= 0.20;

  // Inject a touch of deterministic seed-based variation
  const rand = rng(seed || 1);
  score += (rand() - 0.5) * 0.12;
  score = Math.max(0, Math.min(1, score));

  let status;
  if (score > 0.7) status = "pass";
  else if (score > 0.45) status = "retry";
  else status = "fail";

  return { status, score, mean, peak, peakRatio, range };
}

/* ------------- VoiceMark: a small radial bar fingerprint per voice -------- */
function VoiceMark({ hash = 0x4a7d, size = 32, status = "ready", color, dim = false }) {
  const bars = 36;
  const r = useMemo(() => {
    const rand = rng(hash || 1);
    return new Array(bars).fill(0).map(() => 0.35 + rand() * 0.65);
  }, [hash]);
  const cx = size / 2, cy = size / 2;
  const inner = size * 0.22;
  const outer = size * 0.46;
  const c = color
    || (status === "ready" ? "var(--color-primary)"
      : status === "building" ? "var(--color-accent-amber)"
      : "var(--color-muted-soft)");
  const op = dim ? 0.4 : 1;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{display:'block'}}>
      <g style={{opacity: op}}>
        {r.map((amp, i) => {
          const a = (i / bars) * Math.PI * 2;
          const len = inner + (outer - inner) * amp;
          const x1 = cx + Math.cos(a) * inner;
          const y1 = cy + Math.sin(a) * inner;
          const x2 = cx + Math.cos(a) * len;
          const y2 = cy + Math.sin(a) * len;
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={c} strokeWidth={1.5} strokeLinecap="round"/>;
        })}
      </g>
    </svg>
  );
}

/* ------------- Static Waveform (deterministic, speech-shaped) ------------ */
function StaticWaveform({ seed = 0x1234, bars = 80, height = 64, played = 0, dark = true, color, text = "", duration = null }) {
  const data = useMemo(() => speechBars(seed, bars, text, duration), [seed, bars, text, duration]);
  const playedIdx = Math.floor(played * bars);
  const baseColor = color || (dark ? "rgba(255,255,255,0.18)" : "var(--color-muted-soft)");
  return (
    <div className="waveform-strip" style={{ height }}>
      {data.map((v, i) => (
        <div
          key={i}
          className={`bar ${i < playedIdx ? "played" : ""} ${i === playedIdx ? "cursor" : ""}`}
          style={{
            height: `${Math.max(8, v * 100)}%`,
            background: i < playedIdx ? "var(--color-primary)" : (i === playedIdx ? "#fff" : baseColor),
          }}
        />
      ))}
    </div>
  );
}

/* ------------- MiniWaveform for compact recent-list rows ------------------ */
function MiniWaveform({ seed = 0x1234, bars = 22, height = 28, text = "", duration = null, color }) {
  const data = useMemo(() => speechBars(seed, bars, text, duration), [seed, bars, text, duration]);
  return (
    <div className="recent-mini-waveform" style={{ height }}>
      {data.map((v, i) => <div key={i} className="bar" style={{ height: `${Math.max(12, v * 100)}%`, background: color || undefined }} />)}
    </div>
  );
}

/* ------------- LiveWaveform: animates as if recording --------------------- */
function LiveWaveform({ active = true, bars = 80, height = 96, color = "var(--color-primary)", elapsed = null }) {
  const [t, setT] = useState(0);
  const rafRef = useRef(null);
  useEffect(() => {
    if (!active) return;
    let last = performance.now();
    const tick = (now) => {
      setT(prev => prev + (now - last) * 0.0042);
      last = now;
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [active]);

  /* Speech-like animated wave: syllable bursts ride along, with
     occasional consonant valleys and brief pauses. */
  const data = useMemo(() => {
    const arr = new Array(bars).fill(0);
    for (let i = 0; i < bars; i++) {
      const x = i / (bars - 1);
      // Several moving syllable wavefronts traveling at different speeds
      const s1 = Math.sin(t * 6 - i * 0.45) * 0.5 + 0.5;
      const s2 = Math.sin(t * 3.2 - i * 0.7 + 1.2) * 0.5 + 0.5;
      const s3 = Math.sin(t * 9.1 - i * 0.22) * 0.4 + 0.5;
      // Multiply so brief lulls happen naturally
      let v = (s1 * 0.6 + s2 * 0.5) * s3;
      // Slow phrase envelope — every ~3s of t the energy dips briefly (pause)
      const phrase = 0.55 + 0.45 * (Math.sin(t * 0.8) * 0.5 + 0.5);
      v *= phrase;
      // Edges taper
      const env = Math.min(1, Math.sin(Math.min(1, x / 0.05) * Math.PI / 2),
                              Math.sin(Math.min(1, (1 - x) / 0.05) * Math.PI / 2));
      arr[i] = Math.max(0.06, env * v);
    }
    return arr;
  }, [t, bars]);
  return (
    <div className="waveform-strip" style={{ height }}>
      {data.map((v, i) => (
        <div key={i} className="bar" style={{
          height: `${Math.max(6, v * 100)}%`,
          background: active ? color : "rgba(255,255,255,0.18)",
          transition: "height 80ms ease-out",
        }}/>
      ))}
    </div>
  );
}

/* ------------- Donut: SVG coverage donut ---------------------------------- */
function Donut({ value = 0.75, size = 80, stroke = 8, color = "var(--color-primary)", track = "rgba(255,255,255,0.18)", label }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const dash = c * value;
  return (
    <div className="coverage-donut" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={size/2} cy={size/2} r={r} stroke={track} strokeWidth={stroke} fill="none"/>
        <circle cx={size/2} cy={size/2} r={r}
          stroke={color} strokeWidth={stroke} fill="none"
          strokeDasharray={`${dash} ${c}`}
          strokeLinecap="round"
          transform={`rotate(-90 ${size/2} ${size/2})`}
          style={{ transition: "stroke-dasharray 350ms ease-out" }}
        />
      </svg>
      {label !== undefined && <div className="pct">{label}</div>}
    </div>
  );
}

/* ------------- RippleViz: large radial spike around mic ------------------- */
function RippleViz({ active = true, size = 220, hash = 0x6c1a }) {
  const [t, setT] = useState(0);
  const rafRef = useRef(null);
  useEffect(() => {
    if (!active) return;
    let last = performance.now();
    const tick = (now) => {
      setT(prev => prev + (now - last) * 0.0028);
      last = now;
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [active]);
  const spokes = 64;
  const cx = size / 2, cy = size / 2;
  const inner = size * 0.22;
  const outerBase = size * 0.36;
  const base = useMemo(() => {
    const rand = rng(hash);
    return new Array(spokes).fill(0).map(() => 0.5 + rand() * 0.5);
  }, [hash]);
  const lines = base.map((b, i) => {
    const a = (i / spokes) * Math.PI * 2;
    const phase = i * 0.21;
    const v = active
      ? b * (0.55 + Math.abs(Math.sin(t - phase) * 0.4 + Math.sin(t * 1.8 - phase * 1.3) * 0.3))
      : b * 0.55;
    const r2 = outerBase + (size * 0.10) * v;
    const x1 = cx + Math.cos(a) * inner;
    const y1 = cy + Math.sin(a) * inner;
    const x2 = cx + Math.cos(a) * r2;
    const y2 = cy + Math.sin(a) * r2;
    return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
                 stroke="var(--color-primary)"
                 strokeOpacity={active ? 0.85 : 0.4}
                 strokeWidth={1.8}
                 strokeLinecap="round"/>;
  });
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {lines}
      <circle cx={cx} cy={cy} r={inner - 6} fill="rgba(204,120,92,0.12)"/>
    </svg>
  );
}

/* ------------- Progress bar ---------------------------------------------- */
function Progress({ value = 0.4 }) {
  return (
    <div className="progress-bar">
      <div className="fill" style={{ width: `${Math.round(value * 100)}%` }}/>
    </div>
  );
}

Object.assign(window, {
  VoiceMark, StaticWaveform, MiniWaveform, LiveWaveform, Donut, RippleViz, Progress, rng,
});
