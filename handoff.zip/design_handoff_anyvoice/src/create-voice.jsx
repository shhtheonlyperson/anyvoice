/* Create-voice modal: choose how to build a new voice profile.
   Three paths — record, YouTube, upload. */

const { useState: cvUseState } = React;

function CreateVoiceModal({ onClose, onCreate }) {
  const t = useT();
  const [mode, setMode] = cvUseState(null); // null | "record" | "yt" | "upload"
  const [name, setName] = cvUseState("");
  const [url, setUrl] = cvUseState("");
  const [lang, setLang] = cvUseState("zh-TW");
  const [confirm, setConfirm] = cvUseState(true);

  // Mock parsed metadata that appears once user has typed enough URL
  const ytMeta = url && url.length > 20 ? {
    channel: url.includes("uvxToFIeG5o") ? "Storied · 故事" :
             url.match(/youtube\.com\/([^\/]+)/i) ? "Late-night Reading" : "Audio source",
    title: url.includes("&t=") ? "Quiet hours, episode 14" : "Source clip",
    timestamp: (url.match(/[&?]t=(\d+)/) || [])[1] || "0",
  } : null;

  const fmtTime = (s) => {
    const m = Math.floor(s / 60); const r = s % 60;
    return `${m}:${String(r).padStart(2, "0")}`;
  };

  const submit = () => {
    if (!mode) return;
    if (mode === "record") {
      onCreate({
        name: name || (t("create.defaultName.record") || "新的聲音"),
        source: "record", lang,
      });
    } else if (mode === "yt") {
      if (!url || !confirm) return;
      onCreate({
        name: name || (ytMeta ? ytMeta.channel : t("create.defaultName.yt") || "YouTube 聲音"),
        source: "yt", url, lang,
      });
    } else if (mode === "upload") {
      onCreate({
        name: name || (t("create.defaultName.upload") || "上傳的聲音"),
        source: "upload", lang,
      });
    }
  };

  return (
    <div className="first-run" onClick={onClose}>
      <div className="first-run-card" style={{maxWidth: 620, padding: 36}} onClick={e => e.stopPropagation()}>
        <div className="row between" style={{marginBottom: 4}}>
          <div className="row gap-10">
            <SpikeIcon size={18} style={{color:"var(--color-primary)"}}/>
            <span className="eyebrow" style={{margin:0}}>{t("create.eyebrow")}</span>
          </div>
          <button className="icon-btn" onClick={onClose} title="Close"><IcX size={16}/></button>
        </div>
        <h2 style={{margin: "8px 0 18px"}}>{t("create.title")}</h2>

        {!mode && (
          <>
            <div style={{display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap: 12}}>
              <button className="cv-option" onClick={() => setMode("record")}>
                <IcMic size={20} style={{color:"var(--color-primary)"}}/>
                <div className="cv-option-title">{t("create.opt.record.title")}</div>
                <div className="cv-option-sub">{t("create.opt.record.sub")}</div>
                <div className="cv-option-time">{t("create.opt.record.time")}</div>
              </button>
              <button className="cv-option" onClick={() => setMode("yt")}>
                <IcYoutube size={20} style={{color:"var(--color-primary)"}}/>
                <div className="cv-option-title">{t("create.opt.yt.title")}</div>
                <div className="cv-option-sub">{t("create.opt.yt.sub")}</div>
                <div className="cv-option-time">{t("create.opt.yt.time")}</div>
              </button>
              <button className="cv-option" onClick={() => setMode("upload")}>
                <IcUpload size={20} style={{color:"var(--color-primary)"}}/>
                <div className="cv-option-title">{t("create.opt.upload.title")}</div>
                <div className="cv-option-sub">{t("create.opt.upload.sub")}</div>
                <div className="cv-option-time">{t("create.opt.upload.time")}</div>
              </button>
            </div>
            <div className="mt-20" style={{fontSize: 12, color: "var(--color-muted)", textAlign: "center"}}>
              {t("create.disclaimer")}
            </div>
          </>
        )}

        {mode === "record" && (
          <div>
            <label className="input-label">{t("create.field.name")}</label>
            <input className="input" autoFocus placeholder={t("create.field.name.placeholder.record")} value={name} onChange={e => setName(e.target.value)}/>
            <label className="input-label" style={{marginTop: 18}}>{t("create.field.language")}</label>
            <div className="row gap-8">
              {[["zh-TW", "繁體中文"], ["en-US", "English"], ["ja-JP", "日本語"]].map(([v, l]) => (
                <button key={v} className={`chip ${lang === v ? "active" : ""}`} onClick={() => setLang(v)}>{l}</button>
              ))}
            </div>
            <div style={{background: "var(--color-surface-soft)", borderRadius: 12, padding: 16, marginTop: 18, display:"flex", gap: 12, alignItems:"flex-start"}}>
              <IcInfo size={16} style={{color:"var(--color-muted)", marginTop: 2, flexShrink: 0}}/>
              <div style={{fontSize: 13, color: "var(--color-body)", lineHeight: 1.5}}>
                {t("create.record.guide")}
              </div>
            </div>
            <div className="row gap-8 mt-24" style={{justifyContent:"flex-end"}}>
              <button className="btn btn--ghost" onClick={() => setMode(null)}><IcChevronLeft size={14}/>{t("create.back")}</button>
              <button className="btn btn--primary" onClick={submit}><IcMic size={14}/>{t("create.btn.startRecording")}</button>
            </div>
          </div>
        )}

        {mode === "yt" && (
          <div>
            <div style={{background:"rgba(214, 159, 51, 0.10)", border:"1px solid rgba(214, 159, 51, 0.35)", borderRadius: 10, padding: "10px 14px", marginBottom: 18, fontSize: 13, color: "var(--color-body)", display:"flex", gap: 10, alignItems:"flex-start"}}>
              <span style={{flexShrink:0, marginTop: 1}}>⚠️</span>
              <div>{t("create.yt.playgroundNote")}</div>
            </div>
            <label className="input-label">{t("create.yt.urlLabel")}</label>
            <input className="input" autoFocus placeholder="https://www.youtube.com/watch?v=…&t=300"
              value={url} onChange={e => setUrl(e.target.value)}/>
            <div style={{fontSize: 12, color: "var(--color-muted)", marginTop: 6}}>
              {t("create.yt.hint")}
            </div>
            {ytMeta && (
              <div className="card-cream mt-16" style={{padding: 14, display:"grid", gridTemplateColumns:"auto 1fr", gap: 14, alignItems:"center"}}>
                <div style={{width: 56, height: 56, borderRadius: 8, background:"var(--color-surface-dark)", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center"}}>
                  <IcYoutube size={24}/>
                </div>
                <div>
                  <div style={{fontFamily:"var(--font-body)", fontSize: 14, fontWeight: 500, color:"var(--color-ink)"}}>{ytMeta.title}</div>
                  <div style={{fontSize: 12, color:"var(--color-muted)", marginTop: 2}}>
                    {ytMeta.channel}{ytMeta.timestamp !== "0" && ` · ${t("create.yt.startAt", { time: fmtTime(parseInt(ytMeta.timestamp)) })}`}
                  </div>
                  <div style={{fontSize: 12, color:"var(--color-primary)", marginTop: 2}}>{t("create.yt.willCapture")}</div>
                </div>
              </div>
            )}
            <label className="input-label" style={{marginTop: 18}}>{t("create.field.name")}</label>
            <input className="input" placeholder={ytMeta ? ytMeta.channel : t("create.field.name.placeholder.yt")} value={name} onChange={e => setName(e.target.value)}/>
            <label className="row gap-8 mt-16" style={{fontSize:13, color:"var(--color-body)", cursor:"pointer"}}>
              <input type="checkbox" checked={confirm} onChange={e => setConfirm(e.target.checked)}/>
              {t("create.yt.confirm")}
            </label>
            <div className="row gap-8 mt-24" style={{justifyContent:"flex-end"}}>
              <button className="btn btn--ghost" onClick={() => setMode(null)}><IcChevronLeft size={14}/>{t("create.back")}</button>
              <button className="btn btn--primary" disabled={!url || !confirm} onClick={submit}>
                <IcDownload size={14}/>{t("create.btn.buildFromYt")}
              </button>
            </div>
          </div>
        )}

        {mode === "upload" && (
          <div>
            <label className="input-label">{t("create.field.name")}</label>
            <input className="input" autoFocus placeholder={t("create.field.name.placeholder.upload")} value={name} onChange={e => setName(e.target.value)}/>
            <div style={{
              marginTop: 18,
              border: "2px dashed var(--color-hairline)", borderRadius: 12, padding: 32,
              display:"flex", flexDirection:"column", alignItems:"center", gap: 8, textAlign:"center", cursor:"pointer",
            }}>
              <IcUpload size={22} style={{color:"var(--color-muted)"}}/>
              <div style={{fontFamily:"var(--font-body)", fontSize: 14, fontWeight: 500, color:"var(--color-ink)"}}>{t("create.upload.cta")}</div>
              <div style={{fontSize: 12, color:"var(--color-muted)"}}>{t("create.upload.formats")}</div>
            </div>
            <div className="row gap-8 mt-24" style={{justifyContent:"flex-end"}}>
              <button className="btn btn--ghost" onClick={() => setMode(null)}><IcChevronLeft size={14}/>{t("create.back")}</button>
              <button className="btn btn--primary" onClick={submit}>{t("create.btn.upload")}</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { CreateVoiceModal });
