/* Main app entry: state management + routing across tabs */

const { useEffect, useMemo, useState } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#cc785c",
  "theme": "light",
  "railLayout": "left",
  "density": "comfortable"
}/*EDITMODE-END*/;

function shade(hex, amount) {
  const c = hex.replace("#", "");
  const r = parseInt(c.slice(0,2), 16);
  const g = parseInt(c.slice(2,4), 16);
  const b = parseInt(c.slice(4,6), 16);
  const ad = (v) => Math.max(0, Math.min(255, Math.round(v + (amount < 0 ? v : (255 - v)) * amount)));
  return "#" + [ad(r), ad(g), ad(b)].map(v => v.toString(16).padStart(2, "0")).join("");
}

function localizeGen(gen, lang) {
  const map = lang === "zh"
    ? {"2 minutes ago": "2 分鐘前", "14 minutes ago": "14 分鐘前", "Yesterday": "昨天",
       "Just now": "剛剛", "Mar 17": "3/17"}
    : {"剛剛":"Just now", "2 分鐘前":"2 minutes ago", "昨天":"Yesterday"};
  return { ...gen, timestamp: map[gen.timestamp] || gen.timestamp };
}

function App() {
  const [tweaks, setTweak] = window.useTweaks(TWEAK_DEFAULTS);

  const [voices, setVoices] = useState(window.sampleVoices);
  const [activeVoiceId, setActiveVoiceId] = useState("v_main");
  const [activeTab, setActiveTab] = useState("build");
  const [lang, setLang] = useState("zh");                  // default Traditional Chinese
  const [railCollapsed, setRailCollapsed] = useState(false);
  const [showFirstRun, setShowFirstRun] = useState(false);
  const [showCreateVoice, setShowCreateVoice] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("theme-dark", tweaks.theme === "dark");
    document.documentElement.style.setProperty("--color-primary", tweaks.accent);
    document.documentElement.style.setProperty("--color-primary-active", shade(tweaks.accent, -0.18));
    document.documentElement.lang = lang === "zh" ? "zh-Hant" : "en";
  }, [tweaks.theme, tweaks.accent, lang]);

  const activeVoice = useMemo(() => voices.find(v => v.id === activeVoiceId) || voices[0], [voices, activeVoiceId]);

  const [speakingVoiceId, setSpeakingVoiceId] = useState(null);

  const handleUpdateVoice = (id, patch) => {
    setVoices(prev => prev.map(v => v.id === id ? { ...v, ...patch } : v));
  };

  const handleCreateVoice = (config) => {
    const id = "v_" + Math.random().toString(36).slice(2, 6);
    const hash = Math.floor(Math.random() * 0xffff);
    let status, source;
    if (config.source === "record") { status = "empty"; source = "record"; }
    else if (config.source === "yt") { status = "importing"; source = "yt"; }
    else { status = "importing"; source = "upload"; }
    const v = {
      id,
      name: config.name,
      status,
      source,
      sourceUrl: config.url,
      hash,
      lineCount: 0,
      totalLines: 24,
      lang: config.lang || "en-US",
    };
    setVoices(prev => [...prev, v]);
    setActiveVoiceId(id);
    setActiveTab("build");
    setShowCreateVoice(false);
  };

  const tabContent = (() => {
    if (activeTab === "build") {
      return <BuildPage activeVoice={activeVoice} onChangeTab={setActiveTab} onUpdateVoice={handleUpdateVoice}/>;
    }
    if (activeTab === "generate") {
      const localizedVoices = voices;
      const localizedGens = window.sampleGenerations.map(g => localizeGen(g, lang));
      return <GeneratePage activeVoice={activeVoice} voices={localizedVoices} onChangeTab={setActiveTab}/>;
    }
    if (activeTab === "audiobook") {
      return <AudiobookPage books={sampleBooks} voices={voices} activeVoice={activeVoice} onChangeTab={setActiveTab}/>;
    }
  })();

  return (
    <I18nProvider lang={lang}>
      <WorkspaceShell
        voices={voices}
        activeVoiceId={activeVoiceId}
        onSelectVoice={setActiveVoiceId}
        onCreateVoice={() => setShowCreateVoice(true)}
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        lang={lang}
        onToggleLang={() => setLang(lang === "zh" ? "en" : "zh")}
        theme={tweaks.theme}
        onToggleTheme={() => setTweak("theme", tweaks.theme === "dark" ? "light" : "dark")}
        speakingVoiceId={speakingVoiceId}
        railCollapsed={railCollapsed}
        onToggleRail={() => setRailCollapsed(!railCollapsed)}
      >
        {tabContent}
      </WorkspaceShell>

      {showCreateVoice && (
        <CreateVoiceModal
          onClose={() => setShowCreateVoice(false)}
          onCreate={handleCreateVoice}
        />
      )}

      {showFirstRun && (
        <FirstRunModal onClose={() => setShowFirstRun(false)}/>
      )}

      {/* Tweaks panel */}
      <TweaksPanel title="Tweaks">
        <TweakSection label={lang === "zh" ? "外觀" : "Theme"}/>
        <TweakRadio
          label={lang === "zh" ? "明暗" : "Mode"}
          value={tweaks.theme}
          onChange={(v) => setTweak("theme", v)}
          options={[{value:"light", label: lang === "zh" ? "亮" : "Light"}, {value:"dark", label: lang === "zh" ? "暗" : "Dark"}]}
        />
        <TweakColor
          label={lang === "zh" ? "強調色" : "Accent"}
          value={tweaks.accent}
          onChange={(v) => setTweak("accent", v)}
          options={["#cc785c", "#c64545", "#5db8a6", "#e8a55a", "#4a76b8", "#7a5cc6"]}
        />
        <TweakSection label={lang === "zh" ? "版面" : "Layout"}/>
        <TweakToggle label={lang === "zh" ? "收合側欄" : "Collapse rail"} value={railCollapsed} onChange={setRailCollapsed}/>
        <TweakSection label={lang === "zh" ? "示範狀態" : "Jump to state"}/>
        <TweakSelect
          label={lang === "zh" ? "目前聲音" : "Active voice"}
          value={activeVoiceId}
          onChange={setActiveVoiceId}
          options={voices.map(v => ({value: v.id, label: `${v.name} · ${v.status}`}))}
        />
        <TweakSelect
          label={lang === "zh" ? "頁面" : "Tab"}
          value={activeTab}
          onChange={setActiveTab}
          options={[
            {value:"build", label: lang === "zh" ? "建立聲音" : "Build voice"},
            {value:"generate", label: lang === "zh" ? "生成" : "Generate"},
            {value:"audiobook", label: lang === "zh" ? "有聲書" : "Audiobook"},
          ]}
        />
        <TweakButton label={lang === "zh" ? "顯示歡迎引導" : "Show welcome"} onClick={() => setShowFirstRun(true)}/>
        <TweakButton label={lang === "zh" ? "新增聲音流程" : "Create voice flow"} onClick={() => setShowCreateVoice(true)}/>
      </TweaksPanel>
    </I18nProvider>
  );
}

/* First-run modal — uses i18n */
function FirstRunModal({ onClose }) {
  const t = useT();
  return (
    <div className="first-run" onClick={onClose}>
      <div className="first-run-card" onClick={e => e.stopPropagation()}>
        <div className="row gap-12" style={{marginBottom: 4}}>
          <SpikeIcon size={18} style={{color:"var(--color-primary)"}}/>
          <span className="eyebrow" style={{margin: 0}}>{t("onb.eyebrow")}</span>
        </div>
        <h2>{t("onb.title")}</h2>
        <div className="mt-16">
          {[
            ["1", t("onb.step1.title"), t("onb.step1.desc")],
            ["2", t("onb.step2.title"), t("onb.step2.desc")],
            ["3", t("onb.step3.title"), t("onb.step3.desc")],
          ].map(([n, ti, d]) => (
            <div key={n} className="first-run-step">
              <div className="n">{n}</div>
              <div>
                <div className="ttl">{ti}</div>
                <div className="desc">{d}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="row gap-8 mt-24" style={{justifyContent:"flex-end"}}>
          <button className="btn btn--ghost" onClick={onClose}>{t("onb.btn.later")}</button>
          <button className="btn btn--primary" onClick={onClose}>
            {t("onb.btn.start")} <IcChevron size={14}/>
          </button>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("app"));
root.render(<App/>);
