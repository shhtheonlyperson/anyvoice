/* Generate page: composer with voice + dial controls, dark player,
   recent generations list. */

const { useEffect, useMemo, useRef, useState } = React;

function Dial({ label, value, onChange, min = 0, max = 1, step = 0.05, fmt }) {
  const trackRef = useRef(null);
  const onPointer = (e) => {
    const t = trackRef.current;
    if (!t) return;
    const move = (ev) => {
      const r = t.getBoundingClientRect();
      const x = (ev.clientX - r.left) / r.width;
      const v = Math.max(0, Math.min(1, x)) * (max - min) + min;
      const snapped = Math.round(v / step) * step;
      onChange(Math.max(min, Math.min(max, snapped)));
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    move(e);
  };
  const pct = (value - min) / (max - min);
  return (
    <div className="dial">
      <span className="dial-label">{label}</span>
      <div className="dial-track" ref={trackRef} onPointerDown={onPointer}>
        <div className="dial-fill" style={{ width: `${pct*100}%` }}/>
        <div className="dial-handle" style={{ left: `${pct*100}%` }}/>
      </div>
      <span className="dial-val">{fmt ? fmt(value) : value.toFixed(2)}</span>
    </div>
  );
}

function VoicePicker({ voices, value, onChange }) {
  const [open, setOpen] = useState(false);
  const v = voices.find(x => x.id === value) || voices[0];
  return (
    <div style={{position: "relative"}}>
      <button className="voice-pill" onClick={() => setOpen(o => !o)}>
        <div className="vm-wrap" style={{width: 22, height: 22, position:"relative"}}>
          <VoiceMark hash={v.hash} size={22} status={v.status}/>
        </div>
        <span>{v.name}</span>
        <IcChevronDown size={14}/>
      </button>
      {open && (
        <div style={{
          position:"absolute", top: "calc(100% + 6px)", left: 0,
          background: "var(--color-canvas)",
          border: "1px solid var(--color-hairline)",
          borderRadius: 12,
          padding: 6,
          minWidth: 240,
          boxShadow: "var(--shadow-elevated)",
          zIndex: 10,
        }}>
          {voices.filter(x => x.status === "ready").map(x => (
            <button key={x.id} onClick={() => { onChange(x.id); setOpen(false); }}
              style={{
                display:"grid", gridTemplateColumns:"auto 1fr auto", gap: 10, alignItems:"center",
                padding: 8, borderRadius: 8, border:"none", background: x.id === value ? "var(--color-surface-soft)" : "transparent",
                width: "100%", cursor: "pointer", fontFamily: "var(--font-body)", textAlign:"left",
              }}>
              <VoiceMark hash={x.hash} size={24} status={x.status}/>
              <div>
                <div style={{fontSize: 13, fontWeight: 500, color: "var(--color-ink)"}}>{x.name}</div>
                <div style={{fontSize: 11, color: "var(--color-muted)"}}>{x.subtitle}</div>
              </div>
              {x.id === value && <IcCheck size={14} style={{color: "var(--color-primary)"}}/>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* The dark player surface */
function Player({ generation, onRegenerate, onDownload, onShare, voices }) {
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState(0); // 0-1
  const [speed, setSpeed] = useState(1);
  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setPos(p => {
        const np = p + (0.04 * speed) / generation.duration;
        if (np >= 1) { setPlaying(false); return 0; }
        return np;
      });
    }, 40);
    return () => clearInterval(id);
  }, [playing, speed, generation.duration]);

  useEffect(() => { setPos(0); setPlaying(false); }, [generation.id]);

  const fmt = (s) => {
    const m = Math.floor(s / 60); const r = Math.floor(s % 60);
    return `${m}:${String(r).padStart(2, "0")}`;
  };
  const v = voices.find(x => x.name === generation.voice);
  return (
    <div className="player">
      <div className="player-head">
        <div className="row gap-12">
          <span className="player-eyebrow">Result</span>
          {v && (
            <div className="row gap-8" style={{color: "var(--color-on-dark)"}}>
              <VoiceMark hash={v.hash} size={18}/>
              <span style={{fontSize: 13}}>{v.name}</span>
            </div>
          )}
        </div>
        <div className="player-time">{fmt(pos * generation.duration)} / {fmt(generation.duration)}</div>
      </div>
      <StaticWaveform seed={generation.seed} bars={120} height={76} played={pos} dark={true} text={generation.text} duration={generation.duration}/>
      <div className="player-controls">
        <div className="player-controls-left">
          <button className="play-btn" onClick={() => setPlaying(p => !p)}>
            {playing ? <IcPause size={18}/> : <IcPlay size={18}/>}
          </button>
          <div className="speed-group">
            {[1, 1.25, 1.5, 2].map(s => (
              <button key={s} className={`speed-btn ${speed === s ? "active" : ""}`} onClick={() => setSpeed(s)}>
                {s}×
              </button>
            ))}
          </div>
        </div>
        <div className="player-controls-right">
          <button className="dark-icon-btn" title="Volume"><IcVolume size={16}/></button>
          <button className="dark-link-btn" onClick={onShare}><IcShare size={14}/>Share</button>
          <button className="dark-link-btn" onClick={onDownload}><IcDownload size={14}/>WAV</button>
          <button className="btn btn--secondary-on-dark" onClick={onRegenerate} style={{
            background:"rgba(255,255,255,0.08)", color:"var(--color-on-dark)", height: 36, padding: "0 14px",
            borderRadius: 8, border:"none", fontFamily:"var(--font-body)", fontSize: 13, fontWeight: 500,
            display:"inline-flex", alignItems:"center", gap: 6, cursor:"pointer",
          }}><IcRotate size={14}/>Regenerate</button>
        </div>
      </div>
    </div>
  );
}

/* Recent list row */
function RecentRow({ gen, voices, onPlay, onShare, onCopy }) {
  const v = voices.find(x => x.name === gen.voice);
  return (
    <div className="recent-row" onClick={() => onPlay && onPlay(gen)}>
      <button className="dark-icon-btn" style={{background: "var(--color-surface-soft)", color:"var(--color-ink)"}}>
        <IcPlay size={14}/>
      </button>
      <div style={{minWidth: 0}}>
        <div className="recent-text">{gen.text}</div>
        <div className="recent-meta">
          {v && <span className="row gap-6"><VoiceMark hash={v.hash} size={14} status={v.status}/> {gen.voice}</span>}
          <span className="dot"/>
          <span>{gen.timestamp}</span>
          <span className="dot"/>
          <span>{gen.duration}s</span>
        </div>
      </div>
      <div className="row gap-2">
        <MiniWaveform seed={gen.seed} bars={22} height={24} text={gen.text} duration={gen.duration}/>
        <div className="recent-actions">
          <button className="icon-btn" title="Share" onClick={(e) => { e.stopPropagation(); onShare && onShare(gen); }}><IcShare size={14}/></button>
          <button className="icon-btn" title="Copy text" onClick={(e) => { e.stopPropagation(); onCopy && onCopy(gen); }}><IcCopy size={14}/></button>
          <button className="icon-btn" title="More"><IcDots size={14}/></button>
        </div>
      </div>
    </div>
  );
}

/* Generate page */
function GeneratePage({ activeVoice, voices, onChangeTab }) {
  const t = useT();
  const lang = useLang();
  const [text, setText] = useState(
    lang === "zh"
      ? "台積電是世界頂尖的半導體公司，多年來在世界競爭中持續領先，源自於我們有世界上最優秀的夥伴。 好的工作，不只給你好的福利待遇，更讓你與最厲害的人成為同事。"
      : "I think the best thing about this neighborhood is how the bakery on the corner makes the whole block smell like sourdough every morning around seven."
  );
  const [voiceId, setVoiceId] = useState(activeVoice && activeVoice.status === "ready" ? activeVoice.id : "v_main");
  const [pace, setPace] = useState(0.5);
  const [warmth, setWarmth] = useState(0.6);
  const [pause, setPause] = useState(0.4);
  const [hasResult, setHasResult] = useState(true);
  const [currentGen, setCurrentGen] = useState(sampleGenerations[0]);
  const [genList, setGenList] = useState(sampleGenerations.slice(1));
  const [generating, setGenerating] = useState(false);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(null), 2200);
      return () => clearTimeout(t);
    }
  }, [toast]);

  const onGenerate = () => {
    setGenerating(true);
    setTimeout(() => {
      const v = voices.find(x => x.id === voiceId);
      const newGen = {
        id: "gen_" + Math.random().toString(36).slice(2, 7),
        text,
        voice: v ? v.name : "我的聲音",
        duration: Math.max(5, Math.round(text.length / 12)),
        timestamp: "Just now",
        seed: Math.floor(Math.random() * 0xffff),
      };
      setGenList([currentGen, ...genList]);
      setCurrentGen(newGen);
      setHasResult(true);
      setGenerating(false);
    }, 900);
  };

  const onRowPlay = (g) => {
    setGenList([currentGen, ...genList.filter(x => x.id !== g.id)]);
    setCurrentGen(g);
    setHasResult(true);
  };

  const onShare = (g) => {
    setToast({ msg: t("gen.toast.copied"), icon: <IcCheck size={14}/> });
  };
  const onCopyText = (g) => {
    setText(g.text);
    setToast({ msg: t("gen.toast.textCopied"), icon: <IcCheck size={14}/> });
  };

  return (
    <div className="page-inner">
      <div className="eyebrow">{t("gen.eyebrow")}</div>
      <h1 className="page-title">{t("gen.title")}</h1>
      <p className="page-lede">{t("gen.lede")}</p>

      {/* Composer */}
      <div className="compose-shell mt-32">
        <div className="compose-input-wrap">
          <textarea
            className="compose-textarea"
            value={text}
            onChange={e => setText(e.target.value)}
            placeholder={t("gen.placeholder")}
            rows={3}
          />
        </div>
        <div className="compose-toolbar">
          <div className="compose-tools-left">
            <VoicePicker voices={voices} value={voiceId} onChange={setVoiceId}/>
            <Dial label={t("gen.dial.pace")} value={pace} onChange={setPace} fmt={v => v < 0.4 ? t("gen.pace.slow") : v > 0.6 ? t("gen.pace.brisk") : t("gen.pace.natural")}/>
            <Dial label={t("gen.dial.warmth")} value={warmth} onChange={setWarmth} fmt={v => v < 0.4 ? t("gen.warmth.cool") : v > 0.7 ? t("gen.warmth.warm") : t("gen.warmth.even")}/>
            <Dial label={t("gen.dial.breaths")} value={pause} onChange={setPause} fmt={v => `${(v*0.8).toFixed(2)}s`}/>
          </div>
          <div className="row gap-12">
            <span style={{fontSize: 12, color: "var(--color-muted)"}}>{t("gen.charCount", { n: text.length, s: Math.max(3, Math.round(text.length/12)) })}</span>
            <button className="btn btn--primary" onClick={onGenerate} disabled={generating || !text.trim()}>
              {generating ? <><IcSparkles size={14}/>{t("gen.btn.generating")}</> : <><IcSparkles size={14}/>{t("gen.btn.generate")}</>}
            </button>
          </div>
        </div>
      </div>

      {/* Result */}
      {hasResult && (
        <div className="mt-24">
          <Player generation={currentGen} voices={voices}
            onRegenerate={onGenerate}
            onDownload={() => setToast({msg: t("gen.toast.download"), icon: <IcDownload size={14}/>})}
            onShare={() => setToast({msg: t("gen.toast.copied"), icon: <IcCheck size={14}/>})}
          />
        </div>
      )}

      {/* Recent */}
      <div className="subtabs">
        <button className="subtab active">{t("gen.subtab.recent")}</button>
        <button className="subtab">{t("gen.subtab.favorites")}</button>
        <button className="subtab">{t("gen.subtab.shared")}</button>
        <div style={{flex: 1}}/>
      </div>
      <div style={{marginTop: 8}}>
        {genList.map(g => (
          <RecentRow key={g.id} gen={g} voices={voices} onPlay={onRowPlay} onShare={onShare} onCopy={onCopyText}/>
        ))}
        {genList.length === 0 && (
          <div className="empty-zone">
            <div className="ill"><IcClock size={24}/></div>
            <h3>{t("gen.empty.title")}</h3>
            <p>{t("gen.empty.sub")}</p>
          </div>
        )}
      </div>

      {toast && (
        <div className="toast">{toast.icon}{toast.msg}</div>
      )}
    </div>
  );
}

Object.assign(window, { GeneratePage });
